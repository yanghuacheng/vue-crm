<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------
error_reporting(E_PARSE);
// 应用公共文件
/**
 * saveBase64Img
 * 保存base64的图片
 * @param array $base64Img //图片信息
 * @param string $path default='files' 保存路径
 * @return boolean|string
 */
function saveBase64Img($base64Img){
	if(ISLOCALHOST) $path = "cheshi";else $path = "files";
	if(!session("imageTimes")) session("imageTimes", 1);
	// 匹配出图片的格式
    if (preg_match('/^(data:\s*image\/(\w+);base64,)/', $base64Img, $result)){
        $type = $result[2];
        $samePath = "/Uploads/".$path."/".date('Y-m-d')."/";//图片保存路径公共部分
        if(!file_exists(".".$samePath))
        {
			//检查是否有该文件夹，如果没有就创建，并给予最高权限
			mkdir(".".$samePath, 0777,true);
			chmod(".".$samePath, 0777,true);
        }
        $times = session("imageTimes");
        $sameChar = (time() + $times).(ISLOCALHOST ? rand(9999, 1000000) : str_replace(".","",request()->ip(0))).".{$type}";
        $new_file = $samePath.$sameChar;//原图
		if (!file_put_contents(".".$new_file, base64_decode(str_replace($result[1], '', $base64Img)))) return false;
        $times++;
        session("imageTimes", $times);
		return $new_file;
	} else return false;
}
//文件删除
function delPic($path){
	if($path){
		if(file_exists(".".$path)){
            chmod(".".$path, 0777);
			if(!@unlink(".".$path)) return false;
		}
	}
	return true;
}
/**
 * checkTel
 * 验证手机号码或者电话号码
 * --------------------------------------------------------------------------------
 */
function checkTel($str){
	// $tel = preg_match("/^(((d{3}))|(d{3}-))?((0d{2,3})|0d{2,3}-)?[1-9]d{6,8}$/",$str);
	$phone = preg_match("/^1[345789]\d{9}$/",$str);
	if($phone){
		return true;
	}
	return false;
}
/**
 * 验证邮箱
 */
function checkEmail($email)
{
	// $pattern="/([a-z0-9]*[-_.]?[a-z0-9]+)*@([a-z0-9]*[-_]?[a-z0-9]+)+[.][a-z]{2,3}([.][a-z]{2})?/i";
	$pattern = "/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/";
	if(preg_match($pattern,$email)) return true;else return false;
}
/**
 * 到期时间
 */
function endTime($times)
{
	if($times > time()) return ceil(($times - time())/(24*60*60)).'h';
}