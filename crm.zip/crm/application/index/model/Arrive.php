<?php
namespace app\index\Model;
use think\Model;
/**
 * 
 */
class Arrive extends Model
{
	
	
}