<?php
namespace app\index\Model;
use think\Model;
/**
 * 
 */
class User extends Model
{
	public function goal($id){//本月目标任务金额
        // return $this->hasOne('Goal','uid',"id")->where(['input_time'=>date('Ym',time())])->field("many");
        $goal = db('Goal')->where('uid',$id)->whereTime('input_time','month')->value("many");
        return $goal ? $goal : 0;
    
    }
    public function goal1(){//本月目标任务金额
        return $this->hasOne('Goal','uid',"id")->where(['input_time'=>date('Ym',time())])->field("many");
    }
	public function arrive($id){//本月收到金额
        // return $this->hasMany('Arrive','uid',"id")->where(['input_time'=>date('Ym',time())])->field("money");
        $arrive = array_sum(db("Arrive")->where('uid',$id)->whereTime('input_time','month')->column('money'));
        return $arrive;
    }
    public function money($id){//尾款
        $money = 0;
        $money = array_sum(db("Arrive")->where(['uid'=>$id,'input_time'=>date('Ym',time())])->column('money'));
        return $money;
    }
    public function customer($id){//本月新增签约客户
        $customer = db("Customs")->where(['uid'=>$id,'status2'=>1])->whereTime('input_time','month')->count();
        return $customer ? $customer : 0;
        // return $this->hasOne('Order','uid',"id")->where(['input_time'=>date('Ym',time()),'uid'=>session('crm_id')])->field("count(id) as kehu");
    }
    public function baohu($id){//保护客户
        $baohu = count(db("Customs")->where(['isprivate'=>1,'uid'=>$id])->column("id"));
        return $baohu;
    }
    public function hezuo($id){//保护客户
        $hezuo = count(db("Order")->where(['uid'=>$id])->column("id"));
        return $hezuo;
    }
    public function weikuan($id){//尾款
        $zong = array_sum(db("Goal")->where(['uid'=>$id])->column("many"));
        $dao  = array_sum(db("Arrive")->where(['uid'=>$id])->column("money"));
        $weikuan  = $zong - $dao;
        return $weikuan;
    }
    public function zongweikuan($id){//总客户尾款
        $zong = array_sum(db("Order")->where(['uid'=>$id,'is_shen'=>1])->column("money"));
        $dao  = array_sum(db("Arrive")->where(['uid'=>$id])->column("money"));
        $weikuan['zong']  = $zong;
        $weikuan['dao']  = $dao;
        return $weikuan;
    }
}