<?php
namespace app\index\Model;
use think\Model;
/**
 * 
 */
class Goal extends Model
{
	
	
}