<?php
namespace app\index\Model;
use think\Model;
/**
 * 
 */
class Remind extends Model
{
	
	
}