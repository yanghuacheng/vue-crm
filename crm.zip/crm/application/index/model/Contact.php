<?php
namespace app\index\Model;
use think\Model;
/**
 * 
 */
class Contact extends Model
{
	
	
}