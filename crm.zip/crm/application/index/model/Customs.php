<?php
namespace app\index\Model;
use think\Model;
/**
 * 
 */
class Customs extends Model{
    public function access($id){//跟进
        $times = db("Access")->where(['cid'=>$id])->order("input_time desc")->column("input_time");
        $time = $times ? $times[0] : 0;
        // return $this->hasOne('Access','uid',"id")->where([['is_del','=',0]])->field("(select input_time from crm_access where cid = crm_customs.id order by id desc limit 1) as times");
        return $time;
    }
    public function zongkuan($id,$uid){//zong jin e
        $moeny = [];$moenys = [];
        $lst = db("Order")->where(['cid'=>$id,'uid'=>$uid,'is_shen'=>1])->field("id,cid,money")->select();
        if($lst){
            foreach($lst as $key => $val){
                $moeny[] = array_sum(db("Arrive")->where(['did'=>$val['id']])->column("money"));
                $moenys[] = $val['money'];
            }
        }
        $data['dao'] = array_sum($moeny);
        $data['wei'] = array_sum($moenys) - array_sum($moeny);
        return $data;
    }
    public function daokuan($id,$uid){//到款金额
        $moeny = array_sum(db("Arrive")->where(['cid'=>$id,'uid'=>$uid])->column("money"));
        return $moeny;
    }
    public function express(){//快递
        return $this->hasOne('Express','cid',"id");
    }
    public function zuihou($cid){//最后跟进
        $times = db("Access")->where(['uid'=>$cid,'is_zz'=>0,'is_del'=>0])->order("input_time desc")->column("input_time");
        return $times ? $times[0] : 0;
    }
    public function zuihou1($cid,$uid){//最后跟进
        $times = db("Access")->where(['uid'=>$uid,'cid'=>$cid,'is_del'=>0])->order("input_time desc")->column("input_time");
        return $times ? $times[0] : 0;
    }
    public function order($id,$cid){//下单
        $order = db("Order")->where(['uid'=>$id,'cid'=>$cid])->order("input_time desc")->select();
        return $order[0];
    }
    public function daoqi($id,$uid){//合作到期时间
        $shiajn = db("Order")->where(['cid'=>$id,'uid'=>$uid])->order("end_time desc")->column('end_time');
        return $shiajn ? $shiajn[0] : 0;
    }
    public function lianxi($id){//
        $data = [];
            $name = db("Contact")->where(['cid' => $id,'is_main' => 1])->field("name,phone")->find();
            $data['name'] = $name['name'];
            $data['phone'] = $name['phone'];
        return $data;
    }
    public function zuihoukehu($cid){//最后跟进
        $times = db("Access")->where(['cid'=>$cid,'is_del'=>0])->order("input_time desc")->column("input_time");
        return $times ? $times[0] : 0;
    }
    
	
}