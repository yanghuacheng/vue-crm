<?php
namespace app\index\Model;
use think\Model;
/**
 * 
 */
class Schedule extends Model
{
	
	
}