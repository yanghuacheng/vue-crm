<?php
namespace app\index\Model;
use think\Model;
/**
 * 
 */
class Magazine extends Model
{
	
	
}