<?php
namespace app\index\Model;
use think\Model;
/**
 * 
 */
class Express extends Model
{
	public function magazine($id){//最后跟进
        $info = db("Magazine")->where(['cid'=>$id])->select();
        return $info ? $info : [];
    }
	
}