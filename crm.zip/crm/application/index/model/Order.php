<?php
namespace app\index\Model;
use think\Model;
use think\facade\Config;
/**
 * 
 */
class Order extends Model
{
	public function access(){//
        return $this->hasOne('Access','uid',"id")->where([['is_del','=',0]])->field("(select input_time from crm_access where cid = crm_customs.id order by id desc limit 1) as times");
    }
    public function lianxi($id){//
        $data = [];
            $name = db("Contact")->where(['cid' => $id,'is_main' => 1])->field("name,phone")->find();
            $data['name'] = $name['name'];
            $data['phone'] = $name['phone'];
        return $data;
    }
    public function zuihou($id,$id2){//最后跟进
        $times = db("Access")->where(['uid'=>$id,'cid'=>$id2,'is_zz'=>1,'is_del'=>0])->order("input_time desc")->column("input_time");
        return $times ? date("Y/m/d H:i",$times[0]) : 0;
    }
    public function Magazine($id){//
        $type = config::get("state.MAGAZINE_TYPE");
        if($id){
            $Magazine = db("Magazine")->where('cid',$id)->select();
            foreach($Magazine as $key =>  $val){
                $Magazine[$key]['type'] = $type[$Magazine[$key]['type']];
            }
        }
        return $Magazine ? $Magazine : [];
    }
    public function zuihou1($cid,$uid){//最后跟进
        $times = db("Access")->where(['uid'=>$uid,'cid'=>$cid,'is_zz'=>2,'is_del'=>0])->order("input_time desc")->column("input_time");
        return $times ? date("Y/m/d H:i",$times[0]) : 0;
    }
    public function arrive($id){//收到金额
        // return $this->hasMany('Arrive','uid',"id")->where(['input_time'=>date('Ym',time())])->field("money");
        $arrive = array_sum(db("Arrive")->where('did',$id)->column('money'));
        return $arrive;
    }
    public function zong($id){//总合作金额
        $data = db("Order")->where(['uid'=>$id,'is_shen'=>1])->field('id,money')->select();
        foreach($data as $val){
            $money[] = $val['money'];
            $dao[] = array_sum(db("Arrive")->where('did',$val['id'])->column('money'));
        }
        $arrive['zong'] = $money ? array_sum($money) : 0;
        $arrive['dao'] = $dao ? array_sum($dao) :0;//合作总到款
        return $arrive;
    }
    
}