<?php
namespace app\index\Model;
use think\Model;
/**
 * 
 */
class Access extends Model
{
	
	
}