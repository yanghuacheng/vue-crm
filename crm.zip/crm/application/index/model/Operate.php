<?php
namespace app\index\Model;
use think\Model;
/**
 * 
 */
class Operate extends Model
{
	
	
}