<?php
namespace app\index\controller;
use app\index\controller\Common;
use think\facade\Config;
use sms\Sms;
class Index extends Common
{
	public function initialize()
	{
		$this->magazine_type = config::get("state.MAGAZINE_TYPE");//杂志类型
        $this->kehu_yixiang  = config::get("state.KEHU_YIXIANG");//客户意向
        $this->kehu_state 	 = config::get("state.KEHU_STATE");//客户状态
		$this->kehu_cate 	 = config::get("state.KEHU_CATE");//客户类型
		$this->user_rank	 = config::get("state.USER_RANK");//快递公司
		$this->user_type1	 = config::get("state.USER_TYPEB");//用户身份
		$this->user_type2	 = config::get("state.USER_TYPEC");//用户身份
        $this->pj_cate 		 = config::get("state.PJ_CATE");//配件类
        $this->cp_cate 		 = config::get("state.CP_CATE");//配件类
        $this->express		 = config::get("state.EXPRESS");//快递公司
		$this->rank 			 = session("crm_rank");//用户等级
		$this->uid 			 = session("crm_id");//用户id
		$this->user          = db("User")->column("id,name");//用户
		$this->company       = db("Customs")->column("id,company");//客户
		if (!cache("district")) cache("district", db("District")->column("id,name"));
		$this->chek_shifang();//检测到期自动释放客户
		$this->chek_hezuo();//检测合作到期
		$this->chek_user_leave();//检测到期离职的用户
	}
	public function get_param()
	{
		$data = [];
		if(request()->isAjax()){
			$list =[
				'kehu_yixiang'	=>  $this->kehu_yixiang,
				'kehu_state'	=>	$this->kehu_state,
				'kehu_cate'		=>  $this->kehu_cate,
				'user_type'		=>	$this->user_type,
				'pj_cate'		=>  $this->pj_cate,
				'cp_cate'		=>  $this->cp_cate,
			];
			$data['list'][] = $list;
			$data['status'] = 1;
		}
		return json($data);
	}
    public function index()
	{
		$weekarray = ["日","一","二","三","四","五","六"];
		$this->redirect('./crm/#/login');
		// return "<div style='color:green;font-size:100px;text-align:center;padding-top:300px;'>TP框架版本：".\think\facade\App::version()."</div>"."<div style='text-align:center;'>".date('Y-m-d')." 星期".$weekarray[date('w')]."</div>";
	}
	/**
	 * customer_list
	 * 客户列表
	 */
	public function customer_list()
	{
		$district = cache("district");
		$list = [];
		if(request()->isAjax()){
			$nums = intval(input('type'));//列表类型
			$page = input('page') ? intval(input('page')) : 1;
			if(!$nums) $nums = 1;else $nums = $nums + 1;
			$company = trim(input('company'));
			$map1[] = ['company','like','%'.$company.'%'];
			$map['uid'] = $this->uid;
			$map1[] = ['status','in',[1,2]];
			if(input("lei")) $map['type'] = intval(input("lei"));
			if(input("province")) $map['province'] = intval(input("province"));
			if(input("city")) $map['city'] = intval(input("city"));
			if(input("area")) $map['area'] = intval(input("area"));
			if($nums == 1){//保护客户
				$map1[] = ['isprivate','=',1];
				$map1[] = ['status2','=',0];
				$map1[]	= ['protect_time','>',time()+3*24*60*60];
				$map1[]	= ['is_ji','=',0];
			}elseif($nums == 2){//合作客户
				$map1[] = ['status2','=',1];
			}elseif($nums == 3){//即将释放客户
				$map1[] = ['protect_time','<',time()+3*24*60*60];
			}elseif($nums == 4){//即将到期客户
				$map1[] = ['status2','=',1];
			}
			$custom = model("Customs")->where($map1)->where($map)->field("id,company,type,state,pulse,protect_time,province,city,area,address")->order('input_time desc')->relation(['express'])->page($page,20)->select();
			foreach($custom as $key => $val){
				$custom[$key]['order'] = model("Customs")->order($this->uid,$val['id']);
				if($custom[$key]['order']){
					$custom[$key]['qian'] = model("Customs")->zongkuan($custom[$key]['order']['cid'],$this->uid);
				}
				$custom[$key]['type'] = $this->kehu_cate[$val['type']];
				$custom[$key]['state'] = $this->kehu_state[$val['state']];
				$custom[$key]['pulse'] = $this->kehu_yixiang[$val['pulse']];
				$custom[$key]['daoqi'] = model("Customs")->daoqi($val['id'],$this->uid);
				$custom[$key]['lianxi'] = model("Customs")->lianxi($val['id']);
				$custom[$key]['zuihou'] = model("Customs")->zuihou1($val['id'],$this->uid);
				$custom[$key]['dizhi'] = $district[$val['province']] . $district[$val['city']] . $district[$val['area']] . $val['address'];
				if($nums == 2){
					if($custom[$key]['order']['end_time'] < time()+3*24*60*60) unset($custom[$key]);
					if($custom[$key]['order']['is_shen'] != 1) unset($custom[$key]);
				}
				if($nums == 3){
					if($custom[$key]['protect_time'] > time()+3*24*60*60) unset($custom[$key]);
				}
				if($nums == 4){
					if($custom[$key]['order']['end_time'] > time()+3*24*60*60) unset($custom[$key]);
					if($custom[$key]['order']['is_shen'] != 1) unset($custom[$key]);
				}
			}
			$province = model("Customs")->column("province");
			
			$list['list'] = $custom;
			$list['diqu'] = $this->get_city1(array_unique($province));
			$list['leiX'] = $this->kehu_cate;
			$list['zazhi'] = $this->magazine_type;
			$list['kuaidi'] = $this->express;
			$list['yixiang'] = $this->kehu_yixiang;
			$list['size'] = model("Customs")->where($map1)->where($map)->count();
			$list['status'] = 1;
		}
		return json($list);
	}
	/**
	 * 公共资源
	 * public_resource
	 */
	public function public_resource()
	{
		$district = cache("district");
		$list = [];
		if(request()->isAjax()){
			$map[] = ['status', '=', 1];
			$company = trim(input('company'));
			$page = input('page') ? intval(input('page')) : 1;
			if(input('province')) $map[] = ['province', '=', intval(input('province'))];
			if(input('city')) $map[] = ['city', '=', intval(input('city'))];
			if(input('area')) $map[] = ['area', '=', intval(input('area'))];
			if(input('type')) $map[] = ['type', '=', intval(input('type'))+1];else $map[] = ['type', '=', 1];
			if(input('isprivate')) $map[] = ['isprivate', '=', intval(input('isprivate'))-1];
			$lai = intval(input('lai'));
			if($lai){
				if($lai == 1) $map[] = ['new', '=', 1];//公海
				if($lai == 2) $map[] = ['new', '=',0];//释放
			}
			$data = model("Customs")->where([['company','like','%'.$company.'%']])->where($map)
				->field("id,company,uid,province,city,area,address,state,pulse,isprivate,protect_time,is_ji,new")->order("isprivate asc,input_time desc")->page($page,20)->select();
			foreach($data as $key => $val){
				$data[$key]['name'] = $this->user[$val['uid']];
				$data[$key]['state'] = $this->kehu_state[$data[$key]['state']];
				$data[$key]['pulse'] = $this->kehu_yixiang[$data[$key]['pulse']];
				$times = model('Customs')->access($val['id']);
				$data[$key]['zuihou'] = $times ? date("Y/m/d H:i",$times) : 0;
				$data[$key]['dizhi'] = $district[$val['province']] . $district[$val['city']] . $district[$val['area']] . $val['address'];
			}
			$province = model("Customs")->column("province");
			$list['list'] = $data;
			$list['diqu'] = $this->get_city1(array_unique($province));
			$list['size'] =  model("Customs")->where($map)->count();
			$list['status'] = 1;
		}
		return json($list);
	}
	/**
	 * get_city
	 * 获取列表内的省
	 */
	protected function get_city1($map)
	{
		$province= [];
		foreach($map as $val){
			if($val == 0) continue;
			$province[] = db("District")->where(['id'=>$val,'type' => 1])->field("id,name")->find();
		}
		return $province;
	}
	/**
	 * add_customer
	 * 客户添加
	 */
	public function add_customer()
	{
		$code = ['status'=>0,'msg'=>'添加失败'];
		if(request()->isAjax()){
			$data = input();
			$data['protect_time'] = time();
			$id = intval(input("id"));//是否修改
			if(!$data['city']) return json(['status'=>2,'msg'=>'请填写完整地址']);
			$type = intval($data['type']);
			if($data['cate1']) $data['cate1'] = implode(",",$data['cate1']);
			if($data['cate2']) $data['cate2'] = implode(",",$data['cate2']);
			$company = trim($data['company']);
			if($id){
				if(db("Customs")->where([['company','=',$company],['status','=',1],['id','<>',$id]])->value("id")) return json(['status'=>2,'公司名称已被使用']);
				
				if(model("Customs")->allowField(true)->data($data)->isUpdate(true)->save($data,['id'=>$id])){
					$code = ['status'=>1,'msg'=>'添加成功'];
				}
			}else{
				$data['founder'] = $this->uid;
				$data['input_time'] = time();
				if($data['isprivate'] == 1) {$data['protect_time'] = time()+30*24*60*60;$data['uid'] = $this->uid;}
				if($this->chek_company($company)){
					if(model("Customs")->allowField(true)->data($data)->isUpdate(false)->save()){
						session("cid",model("Customs")->id);
						$data = [
							'uid' 	=> $this->uid,
							'cid'	=> session("cid"),
							'type'	=> 1,
							'form'	=> 'customs',
							'keyword'=>'添加了新客户'.$this->user[model("Customs")->id],
						];
						$this->make_operate($data);//记录
						$code = ['status'=>1,'msg'=>'添加成功'];
					};
				}else{
					$code = ['status'=>2,'msg'=>'公司已存在'];
				}
			}
		}
		return json($code);
	}
	/**
	 * add_customer_contact
	 * 添加客户联系
	 */
	public function add_contact()
	{
		$code = ['status'=>0,'msg'=>'添加失败'];
		if(request()->isAjax()){
			$id = intval(input("id"));//是否修改
			$data = input("lianxi");
			if($id) $cid = $id;else $cid = session("cid");
			$info = db("Contact")->where('cid',$cid)->value("id");
			if($data){
				foreach ($data as $key => $value) {
					$data[$key]['cid'] = $cid;
					if($data[$key]['is_main']) $data[$key]['is_main'] = 1;
					if(!$data[$key]['phone']) return json(['status'=>2,'msg'=>'手机号码必须填写']);
				}
				if($info) db("Contact")->where('cid',$cid)->delete();
				if(model("Contact")->saveAll($data)){
					$data = [
						'uid' 	=> $this->uid,
						'cid'	=> $cid,
						'type'	=> 3,
						'form'	=> 'contact',
						'keyword'=>'修改'.$this->company[$cid].'客户的联系人',
					];
					$this->make_operate($data);//记录
					session("cid",null);
				};
				$code = ['status'=>1,'msg'=>'添加成功'];
			}
		}
		return json($code);
	}
	/**
	 * user_list
	 * 用户列表
	 */
	public function user_list()
	{
		$list = [];
		if(request()->isAjax()){
			if(in_array($this->rank,[0,1])) {
				$rank = input('rank') ? intval(input('rank')) : 1;
				$pid = input('pid') ? intval(input('pid')) : 0;
				$list['list'] = db("User")->where([['rank','=',$rank],['pid','=',$pid],['status','in',[1,2]]])->field("id,name,sex,rank,pid,type1,phone,type2")->select();
			}
			if($this->rank == 2){
				$rank = input('rank') ? intval(input('rank')) : 2;
				$pid = intval(input('pid'));
				$list['list'] = db("User")->where([['id','=',$this->uid],['rank','=',$rank],['status','in',[1,2]]])->field("id,name,sex,rank,pid,type1,type2")->select();
				if($pid) $list['list'] = db("User")->where([['pid','=',$pid],['rank','=',$rank],['status','in',[1,2]]])->field("id,name,sex,rank,pid,type1,type2")->select();
			} 
			foreach($list['list'] as $key => $val){
				$list['list'][$key]['goal'] = model("User")->goal($val['id']);
				$list['list'][$key]['arrive'] = model("User")->arrive($val['id']);
				$list['list'][$key]['weikuan'] = model("User")->weikuan($val['id']);
				$list['list'][$key]['shenfen'] = $this->user_type1[$val['type1']]; 
			}
			$list['shenfen']['a'] = config::get("state.USER_RANK");
			$list['shenfen']['b'] = config::get("state.USER_TYPEB");
			$list['shenfen']['c'] = config::get("state.USER_TYPEC");
			$list['status'] = 1;
		}
		return json($list);
	}
	/**
	 * add_gola
	 * 填写本月目标
	 */
	public function add_goal()
	{
		$code = ['status'=>0];
		if(request()->isAjax()){
			$data['input_time'] = time();
			$data['many'] = trim(input('many'));
			$id = intval(input('id'));
			$aid = db("Goal")->where(['uid'=>$id])->whereTime('input_time','month')->value('id');
			if($id == $this->uid) $ss = '自己';else $ss = $this->user[$id];
			if($aid) {
				$res = model("Goal")->allowField(true)->isUpdate(true)->save($data,['id'=>$aid,'uid'=>$id]);
				if($res){
					$data = [
						'uid' 	=> $this->uid,
						'uid2'	=> $id,
						'type'	=> 3,
						'form'	=> 'goal',
						'keyword'=>'修改了'.$ss.'本月目标金额',
					];
					$this->make_operate($data);//记录
					if($id != $this->uid){
						$data1 = [
							'uid' => $id,
							'content' => $this->user[$this->uid].'修改了你的本月目标金额。',
						];
						$this->make_remind($data1);
					}
					$code = ['status'=>1,'msg'=>'修改成功'];
				} 
			}else{
				$data['uid'] = $id;
				$res =  model("Goal")->allowField(true)->isUpdate(false)->save($data);
				if($res) {
					$data = [
						'uid' 	=> $this->uid,
						'uid2'	=> $id,
						'type'	=> 1,
						'form'	=> 'goal',
						'keyword'=>'新增了本月目标金额',
					];
					$this->make_operate($data);//记录
					if($id != $this->uid){
						$data1 = [
							'uid' => $id,
							'content' => $this->user[$this->uid].'给你分配了本月目标金额。',
						];
						$this->make_remind($data1);
					}
					$code = ['status'=>1,'msg'=>'添加成功'];
				}else $code = ['status'=>2,'msg'=>'添加失败'];
			}
		}
		return json($code);
	}
	/**
	 * my_self
	 * 我的相关信息
	 */
	public function my_self()
	{
		$data= [];
		if(request()->isAjax()){
			$data['daokuan'] =  model("user")->arrive($this->uid);
			$data['goal'] =  model("user")->goal($this->uid);
			$data['xin'] = model("user")->customer($this->uid);
			$data['weikuan'] = model("Order")->zong($this->uid);
		}
		return json($data);
	}
	/**
	 * my_customer_info
	 * 我的客户信息
	 */
	public function my_customer_info()
	{
		$data= [];
		if(request()->isAjax()){
			$data['yixiang'] = count(db("Customs")->where(['uid'=>$this->uid,'pulse'=>3])->column('id'));
			$data['ylx'] 	 = count(db("Customs")->where(['uid'=>$this->uid,'type'=>1])->column('id'));
			$data['yph'] 	 = count(db("Customs")->where(['uid'=>$this->uid,'type'=>2])->column('id'));
			$data['baohu'] 	 = count(db("Customs")->where([['uid','=',$this->uid],['isprivate','=',1],['status2','=',0],['protect_time','>',time()+60*60],['status','in',[1,2]]])->column('id'));
			$data['daoqi'] 	 = count(db("Customs")->alias("c")->join("Order o","c.id=o.cid")->where([['c.uid','=',$this->uid],['c.status2','=',1],['o.end_time','<',time()+3*24*60*60],['c.status','in',[1,2]]])->column('c.id'));
			$data['shifang'] = count(db("Customs")->where([['uid','=',$this->uid],['protect_time','<',time()+3*24*60*60],['status','in',[1,2]]])->column('id'));
			$data['qian'] 	 = model("Order")->zong($this->uid);
		}
		return json($data);
	}
	/**
	 * customer_xiangxi
	 * 客户详细资料
	 */
	public function customer_xiangxi()
	{
		$data = [];
		if(request()->isAjax()){
			$cid = intval(input('cid'));
			$data['jiben'] = $this->kehu_jiben($cid);
			$data['kehu'] = $this->kehu_xinxi($cid);
			$data['lianxi'] = $this->kehu_lianxi($cid);
		}
		return json($data);
	}
	protected function kehu_xinxi($cid)
	{
		$district = cache("district");
		$data = db("Customs")->where('id',$cid)->field("id,company,type,state,zhuying,pulse,cate1,cate2,province,city,area,address,status,input_time,uid")->find();
		$data['type'] = $this->kehu_cate[$data['type']];
		$data['state'] =  $this->kehu_state[$data['state']];
		$data['pulse'] =  $this->kehu_yixiang[$data['pulse']];
		$data['fuze'] = $this->user[$data['uid']];
		//----------
		foreach( explode(",",$data['cate1']) as $val){
			if($val == 0 || $val == '') continue;
			$cat1[] = $this->pj_cate[$val];
		}
		$cate1 = $cat1 ? $cat1 : [];
		foreach( explode(",",$data['cate2']) as $val){
			if($val == 0 || $val == '') continue;
			$cat2[] = $this->cp_cate[$val];
		}
		$cate2 = $cat2 ? $cat2 : [];
		$cate = array_merge($cate1,$cate2);
		$data['cate'] = implode("、",$cate);
		//--------
		$data['dizhi'] = $district[$data['province']] . $district[$data['city']] . $district[$data['area']] . $data['address'];
		$data['input_time'] = date("Y/m/d H:i",$data['input_time']);
		return $data;
	}
	protected function kehu_lianxi($cid)
	{
		$data = db("Contact")->where('cid',$cid)->select();
		return $data;
	}
	protected function kehu_jiben($cid)
	{
		$data = [];
		$data = db("Order")->where(['cid'=>$cid,'uid'=>$this->uid,'is_shen'=>1])->find(max('input_time'));
		$data['end_time'] = $data['end_time'] ? date("Y年m月d日",$data['end_time']) : '';
		$data['daokuan'] = model("Customs")->daokuan($data['id']);
		$data['zong'] = array_sum(db("Order")->where(['cid'=>$cid,'uid'=>$this->uid,'is_shen'=>1])->column('money'));
		$zuichu = db("Order")->where(['cid'=>$cid,'uid'=>$this->uid,'is_shen'=>1])->field('input_time')->find(min('input_time'));
		$data['zuichu'] = $zuichu ? date("Y年m月d日",$zuichu['input_time']) : '';
		$data['hezzuocishu'] = db("Order")->where(['cid'=>$cid,'uid'=>$this->uid,'is_shen'=>1])->count();
		$data['fuze'] = $this->user[$data['uid']];
		$data['hetong'] = db("Order")->where(['cid'=>$cid,'uid'=>$this->uid,'is_shen'=>1])->column('cr_file');
		$data['genjin'] = db("Access")->where(['cid'=>$cid,'uid'=>$this->uid,'is_zz'=>0])->count();
		return $data;
	}
	/**
	 * edit_company_name
	 * 修改公司名
	 */
	public function edit_company_name()
	{
		$code = ['status'=>0];
		if(request()->isAjax()){
			$company = trim(input("company"));
			$cid = intval(input("cid"));
			$name = db("Customs")->where([['company','=',$company],['status','in',[1,2]],['id','=',$cid]])->field("company,uid")->find();
			if($info['company']){
				if(db("Customs")->where([['company','=',$company],['status','in',[1,2]],['id','<>',$cid]])->value("id")) return json(['status'=>2,'msg'=>'此名称已被使用']);
			}
			if(db("Customs")->where([['status','in',[1,2]],['id','=',$cid]])->setField('company',$company)){
				$data = [
					'uid' 	=> $this->uid,
					'cid'	=> $data['cid'],
					'type'	=> 3,
					'form'	=> 'customs',
					'keyword'=>'把用户名'.$name['company'].'修改成'.$company,
				];
				$this->make_operate($data);//记录
				if($name['uid'] != $this->uid){
					$data1 = [
						'uid' => $name['uid'],
						'content' => $this->user[$this->uid].'把你跟进的客户'.$name['company'].'修改成'.$company,
					];
					$this->make_remind($data1);
				}
				$code = ['status'=>1];
			}
		}
		return json($code);
	}
	/**
	 * add_customer_contact
	 * 新增客户联系
	 */
	public function add_customer_contact()
	{
		$code = ['status'=>0,'msg'=>'添加失败'];
		if(request()->isAjax()){
			$info = input();
			if(!$info['phone']) return json(['status'=>2,'msg'=>'手机号码必须填写']);
			if(db("Contact")->insert($info)){
				$data = [
					'uid' 	=> $this->uid,
					'cid'	=> $info['cid'],
					'type'	=> 1,
					'form'	=> 'contact',
					'keyword'=>'更新了客户的联系人',
				];
				$this->make_operate($data);//记录
				$code = ['status'=>1,'msg'=>'添加成功'];
			}
		}
		return json($code);
	}
	/**
	 * update_main
	 * 更改主要联系人
	 */
	public function update_main()
	{
		$code = ['status'=>0,'msg'=>'修改失败'];
		if(request()->isAjax()){
			$id = intval(input('id'));
			$cid = intval(input('cid'));
			if(db("Contact")->where(['id'=>$id,'cid'=>$cid])->setField("is_main",1)){
				db("Contact")->where([['id','<>',$id],['cid','=',$cid]])->setField("is_main",0);
				$data = [
					'uid' 	=> $this->uid,
					'cid'	=> $cid,
					'type'	=> 3,
					'form'	=> 'contact',
					'keyword'=>'修改主联系人',
				];
				$this->make_operate($data);//记录
				$code = ['status'=>1,'msg'=>'修改成功'];
			}
		}
		return json($code);
	}
	/**
	 * customer_order
	 * 客户下单列表
	 */
	public function customer_order()
	{
		$list = [];
		if(request()->isAjax()){
			$cid = intval(input('cid'));
			$lst =  model("Order")->alias("o")->join('Customs a','o.cid=a.id')->where(['o.cid'=>$cid,'o.uid'=>$this->uid,'is_shen'=>1])
				->field("o.id,o.money,o.charter,o.is_bill,o.cr_file,o.zl_file,o.content,o.ad_code,o.memo,o.advice,o.is_shen,o.input_time,o.end_time,a.type,a.company")->order('o.input_time desc')->select();
			foreach($lst as $key => $val){
				$lst[$key]['daokuan'] = db("Arrive")->where('did',$val['id'])->column("money");
				$lst[$key]['type'] = $this->kehu_cate[$val['type']];
				$lst[$key]['input_time'] = date("Y/m/d H:i",$val['input_time']);
				$lst[$key]['end_time'] = date("Y/m/d",$val['end_time']);
			}
			$list['list'] = $lst;
			$list['status'] = 1;
		}
		return json($list);
	}
	/**
	 * edit_order
	 * 修改订单did cid
	 */
	public function edit_order()
	{
		$code = ['status'=>0];
		if(request()->isAjax()){
			$data = input();
			$data['uid'] = $this->uid;
			$data['input_time'] = time();
			if(db("Arrive")->insert($data)){
				$data = [
					'uid' 	=> $this->uid,
					'cid'	=> $data['cid'],
					'type'	=> 3,
					'form'	=> 'arrive',
					'keyword'=>'修改了订单到款金额'
				];
				$data1 = [
					'uid' => 0,
					'content' => $this->user[$this->uid].'修改了“'.$this->company[$data['cid']].'”的到款金额，请您尽快查看。',
				];
				$this->make_operate($data);//记录
				$this->make_remind($data1);
				$code = ['status'=>1];
			} 
		}
		return json($code);
	}
	/**
	 * kefu_info
	 * 客服——我的信息
	 */
	public function kefu_info()
	{
		$data = [];
		if(request()->isAjax()){
			$data['deng'] = count(db("Order")->where(['is_shen'=>0])->column('id'));
			$data['wei'] = count(db("Order")->where(['is_shen'=>2])->column('id'));
			$data['guo'] = count(db("Order")->where(['is_shen'=>1])->column('id'));
			$data['dai'] = count(db("Express")->where(['is_pass'=>0])->column('id'));
		}
		return json($data);
	}
	/**
	 * kefu_tixing
	 * 客服B提醒
	 */
	public function kefu_tixing()
	{
		$list = [];
		if(request()->isAjax()){
			$lst = db("Remind")->where([['uid','=',0]])->order("clook asc,time desc")->limit(40)->select();
			foreach($lst as $key => $val){
				$lst[$key]['time'] = date("Y/m/d H:i",$val['time']);
			}
			$list['list'] = $lst;
			$list['status'] = 1;
		}
		return json($list);
	}
	/**
	 * kefu_tixingC
	 * 客服C提醒
	 */
	public function kefu_tixingC()
	{
		$list = [];
		if(request()->isAjax()){
			$lst = db("Remind")->where([['uid','=',$this->uid]])->order("clook asc,time desc")->limit(40)->select();
			foreach($lst as $key => $val){
				$lst[$key]['time'] = date("Y/m/d H:i",$val['time']);
			}
			$list['list'] = $lst;
			$list['status'] = 1;
		}
		return json($list);
	}
	/**
	 * kefu_orders
	 * 客服C订单列表
	 */
	public function kefu_orders()
	{
		$list = [];
		if(request()->isAjax()){
			$id = input('id') ? intval(input('id')) : $this->uid;
			$page = input('page') ? intval(input('page')) : 1;
			$lst =  model("Order")->alias("o")->join('Customs a','o.cid=a.id')->where(['kid'=>$id,'is_shen'=>1])
				->field("o.id,o.uid,a.id as cid,a.type,a.company")->order('o.input_time desc')->page($page,20)->select();
			foreach($lst as $key => $val){
				$lst[$key]['type'] = $this->kehu_cate[$val['type']];
				$lst[$key]['zuihou'] = model("Order")->zuihou1($val['cid'],$this->uid);
				$lst[$key]['uid'] = $this->user[$val['uid']];
				$lst[$key]['lianxi'] = model("Order")->lianxi($val['id']);
			}
			$list['list'] = $lst;
			$list['yixiang'] = $this->kehu_yixiang;
			$list['status'] = 1;
		}
		return json($list);
	}
	/**
	 * 客户检测
	 * chek_customer
	 */
	public function chek_company($company)
	{
		$company = trim($company);
		if(db("Customs")->where([['company','=',$company],['status','in',[1,2]]])->value("id")) return false;else return true;
	}
	/**
	 * 用户检测
	 * chek_user
	 */
	public function chek_user($name)
	{
		if(db("User")->where([['name','=',$name],['status','in',[1,2]]])->value("id")) return false;else return true;
	}
	/**
	 * 手机检测
	 * chek_phone
	 */
	public function chek_phone($phone)
	{
		if(db("User")->where([['phone','=',$phone],['status','in',[1,2]]])->value("id")) return false;else return true;
	}
	/**
	 * 添加用户
	 * add_user
	 */
	public function add_user()
	{
		$code = ['status' => 0];
		if(request()->isAjax()){
			$info = input();
			$id = intval($info['id']);//is_add
			$info['input_time'] = time();
			$info['inputid'] = $this->uid;
			if(in_array($info['rank'],[2,3])) $info['pid'] = $this->uid;
			if($info['rank'] == 3) {
				$info['type1'] = session("crm_type1");

				if(session("crm_type1") == 2 && !$info['type2']) return json(['status' => 2,'msg' => '身份选择错误']);
			}
			if(in_array($info['rank'],[2,3]) && !isset($info['type1'])) return json(['status' => 2,'msg' => '身份1选择错误']);
			
			if($info['password'] != $info['password1']) return json(['status' => 2,'msg' => '两次密码不一致']);
			if(!checkTel(trim($info['phone']))) return json(['status' => 2,'msg' => '手机号码不正确']);
			if(!$this->chek_user(trim($info['name']))) return json(['status' => 2,'msg' => '用户名已存在']);
			if(!$this->chek_phone(trim($info['phone']))) return json(['status' => 2,'msg' => '手机号已被注册']);
			$info['password'] = md5(sha1(trim($info["password"])));

			if(model('User')->allowField(true)->isUpdate(false)->save($info)){
				$data = [
					'uid' 	=> $this->uid,
					'uid2'	=> model("User")->id,
					'type'	=> 1,
					'form'	=> 'user',
					'keyword'=>'添加了新同事'.$this->user[model("User")->id],
				];
				$this->make_operate($data);//记录
				$code = ['status' => 1,'msg' => '添加成功'];
			}
		}
		return json($code);	
	}
	/**
	 * user_edit
	 * 编辑用户
	 */
	public function user_edit()
	{
		$code = ['status'=>0];
		if(request()->isAjax()){
			$info_data = input();
			$id = intval($info_data["id"]);
			$res = db("User")->where('id',$id)->find();
			if($res){
				if($info_data['phone'] != $res['phone']){
					if(!$this->chek_phone(trim($info_data['phone']))) return json(['status'=>2,'msg'=>'用户名已存在']);
					if(!checkTel(trim($info_data['phone']))) return json(['status' => 2,'msg' => '手机号码不正确']);
				}
				$info['phone'] = $info_data['phone'];
				$info['name'] = $info_data['name'];
				if($info_data['password']){
					$info['password'] = md5(sha1(trim($info_data["password"])));
				}
				if(model('User')->allowField(true)->isUpdate(true)->save($info,['id'=>$id])) {
					$data = [
						'uid' 	=> $this->uid,
						'uid2'	=> $id,
						'type'	=> 3,
						'form'	=> 'user',
						'keyword'=>'修改资料'
					];
					$this->make_operate($data);//记录
					if($id != $this->uid){
						$data1 = [
							'uid' => $id,
							'content' => $this->user[$this->uid].'修改了你的个人资料。',
						];
						$this->make_remind($data1);
					}
					$code = ['status' => 1,'msg' => '修改成功'];
				}
			}else return json(['status'=>2,'msg'=>'非法操作']);
		}
		return json($code);
	}
	/**
	 * Deployment
	 * 人员调配
	 */
	public function user_deployment()
	{
		$code = ['status' => 0];
		if(request()->isAjax()){
			$data = input();$id = $data['id'];$id2 = $data['id2'];
			$info = [];
			if($this->rank < 2) return json(['status'=>2,'msg'=>'你没有这个权限']);
			$resss = db("User")->where('id',$id)->field("id,rank,pid,type1,type2")->find();//被分配的人员
			$res   = db("User")->where('id',$id2)->field("id,rank,pid,type1,type2")->find();//分配到这里
			if($res && $resss){
				if($resss['rank'] == 2){
					$resc =  db("User")->where('pid',$resss['id'])->column("id");
					if($resc) return json(['status'=>2,'msg'=>'该组长下面还有组员，不能调配']);
				}
				if($this->rank > $res['rank']) return json(['status'=>2,'msg'=>'你不能越级操作']);
				if(!in_array($res['rank'],[1,2])) return json(['status'=>2,'msg'=>'人员不能调配到这里']);//分到组里的人的等级
				// if($resss['rank'] < 2) return json(['status'=>2,'msg'=>'你不能调配此人员']);//被调配人的等级
				if($res['id'] == $resss['pid']) return json(['status'=>2,'msg'=>'位置没有改变']);//分到组里的人的等级
				if($res['type1'] && ($res['type1'] != $resss['type1'])) return json(['status'=>2,'msg'=>'人员不能跨身份调配']);
				$info['pid'] = $res['id'];
				$info['rank'] = $res['rank'] + 1;
				if(model('User')->allowField(true)->isUpdate(true)->save($info,['id'=>$id])){
					$data = [
						'uid' 	=> $this->uid,
						'uid2'	=> $id,
						'type'	=> 3,
						'form'	=> 'user',
						'keyword'=>'进行了调配'
					];
					$data1 = [
						'uid' => $id,
						'content' => '你被'.$this->user[$id2].'调配到'.$this->user[$info['pid']].'组里。',
					];
					$this->make_operate($data);//记录
					$this->make_remind($data1);
					$code = ['status' => 1,'msg' => '调配成功'];
				}
			}
		}
		return json($code);
	}
	/**
	 * user_leave
	 * 人员离职
	 */
	public function user_leave()
	{
		$code = ['status'=>0];
		if(request()->isAjax()){
			$id = intval(input('id'));
			if($this->rank != 1) return json(['status'=>2,'msg'=>'你没有操作权限']);
			$res = db("User")->where('id',$id)->field("id,rank,pid,type1,type2")->find();
			if($res){
				if($this->rank >= $ress['rank']) return json(['status'=>2,'msg'=>'你不能跨级操作']);
				// if($this->rank == 2 && (session("crm_type1") != $ress['type1'])) return json(['status'=>2,'msg'=>'你不能跨身份操作']);
				if(db("User")->where([['pid','=',$id,'status','in',[1,2]]])->column('id')) return json(['status'=>2,'msg'=>'该人员还有下属存在，不能进行此操作']);
				if(model('User')->isUpdate(true)->save(['status'=>2,'leave_time'=>time()+30*24*60*60],['id'=>$id])){
					$data = [
						'uid' 	=> $this->uid,
						'uid2'	=> $id,
						'type'	=> 3,
						'form'	=> 'user',
						'keyword'=>'进行了离职'
					];
					$data1 = [
						'uid' => $id,
						'content' => $this->user[$this->uid].'对你进行了离职操作，你的账号将在30天后被冻结。',
					];
					$this->make_operate($data);//记录
					$this->make_remind($data1);
					$code = ['status' => 1,'msg' => '操作成功'];
				}
			}
		}
		return json($code);
	}
	/**
	 * get_user
	 * 获取用户
	 */
	public function get_user()
	{
		$data = [];
		if(request()->isAjax()){
			$id = intval(input("id"));
			if($id){
				$data = model("User")->where('id',$id)->field("id,name,rank,pid,phone,input_time,type1,type2,inputid")->find();
				$data['baohu'] = model("User")->baohu($id);
				$data['hezuo'] = model("User")->hezuo($id);
				$data['daokuan'] = model("User")->money($id);
				$data['weikuan'] = model("User")->weikuan($id);
				$data['goal'] = model("User")->goal($id);
				$data['jian'] = $this->user[$data['inputid'] ? $data['inputid'] : $data['pid']];
				$data['rank'] = $this->user_rank[$data['rank']];
				$data['input_time'] = date("Y/m/d H:i",$data['input_time']);
				$data['status'] = 1;
				$data['type1'] = $this->user_type1[$data['type1']];
			}else $data = ['status'=>2,'msg'=>'非法操作'];
		}
		return json($data);
	}
	
	/**
	 * user_customer
	 * 用户的客户列表
	 */
	public function user_customer()
	{
		$district = cache("district");
		$list = [];
		if(request()->isAjax()){
			$id = intval(input("id"));
			$company = trim(input("company"));
			$map['status'] = 1;
			if(input('type')){
				$map['isprivate'] = 1;
				$map['status2'] = 1;
			} else $map['status2'] = 0;
			if(input('province')) $map['province'] = intval(input('province'));
			if(input('city')) $map['city'] = intval(input('city'));
			if(input('area')) $map['area'] = intval(input('area'));
			$page = input('page') ? intval(input('psge')) : 1;
			if($id){
				$map['uid'] = $id;
				$data = db("Customs")->where($map)->where([['company','like','%'.$company.'%']])->field("id,company,type,protect_time,province,city,area,address,isprivate,status2,uid")
						->order('input_time desc')->page($page,20)->select();
				foreach($data as $key => $val){
					$data[$key]['lianxi'] = model("Customs")->lianxi($val['id']);
					$data[$key]['dizhi'] = $district[$val['province']] . $district[$val['city']] . $district[$val['area']] . $val['address'];
					$data[$key]['end_time'] = model("Customs")->zuihou($val['id']);
					$data[$key]['leiX'] = $this->kehu_cate[$val['type']];
					$data[$key]['daoqi'] = model("Customs")->daoqi($val['id'],$val['uid']);
				}
				$province = model("Customs")->column("province");
				$list['list'] = $data;
				$list['kefu'] = db("User")->where([['rank','>',1],['type1','=',1],['status','=',1]])->field("id,name")->select();
				$list['diqu'] = $this->get_city1(array_unique($province));
				$list['status'] = 1;
			}
		}
		return json($list);
	}
	/**
	 * 修改密码
	 */
	public function update_password()
	{
		$code = ['status' => 0];
		if(request()->isAjax()){
			$info = input();
			$rank = $this->rank;
			if(!db('User')->where(['id'=>$this->uid,'password'=>md5(sha1(trim($info["password"])))])->value("id")) return json(['status' => 2,'msg' => '原密码不正确']);
			if($info['password1'] != $info['password2']) return json(['status' => 2,'msg' => '两次密码输入不一致']);
			// if(!$this->check_sms_code(intval(input("code")))) return json(['status' => 2,'msg' => '验证码不正确']);
			$res = model("User")->allowField(true)->isUpdate(true)->save(['password' => md5(sha1(trim($info["password1"])))],['id' => $this->uid]);
			if($res){
				$data = [
					'uid' 	=> $this->uid,
					'type'	=> 3,
					'form'	=> 'user',
					'keyword'=>'修改了登录密码'
				];
				$data1 = [
					'uid' => $this->uid,
					'content' => '你修改了登录密码，请记住新密码！',
				];
				$this->make_operate($data);//记录
				$this->make_remind($data1);
				$code = ['status' => 1,'msg' => '修改成功'];
			}
		}
		return json($code);
	}
	/**
	 * 添加日程
	 */
	public function add_schedule()
	{
		$code = ['status' => 0];
		if(request()->isAjax()){
			$info = [
				'uid' 	 	=> $this->uid,
				'up_time' 	=> time(),
				'plan_time' => strtotime(input('plan_time')),
				'content'	=> input('content'),
			];
			if(model("Schedule")->allowField(true)->isUpdate(false)->save($info)){
				$data = [
					'uid' 	=> $this->uid,
					'type'	=> 1,
					'form'	=> 'schedule',
					'keyword'=>'添加了新日程'
				];
				$this->make_operate($data);//记录
				$code = ['status' => 1,'msg' => '添加成功'];
			}
		}
		return json($code);
	}
	/**
	 * schedule_list
	 * 日程列表
	 */
	public function schedule_list()
	{
		$list = [];
		if(request()->isAjax()){
			$id = intval(input("id"));
			$page = input('page') ? intval(input('page')) : 1;
			$time1 = input("time1") ? strtotime(trim(input("time1"))) : strtotime(date("Y-m-d",time()));
			$time2 = strtotime(trim(input("time2")));
			if(!$id) $id = $this->uid;
			if($time2) $lst = db("Schedule")->where([['uid','=',$id],['plan_time','between time',[$time1, $time2]]])->order("plan_time desc,id desc")->page($page,20)->select();
			else $lst = db("Schedule")->where('uid',$id)->order("plan_time desc,id desc")->select();
			foreach($lst as $key => $val){
				$lst[$key]['input_time'] = date("Y/m/d H:i",$lst[$key]['input_time']);
				$lst[$key]['plan_time'] = date("Y/m/d",$lst[$key]['plan_time']);
			}
			$list['list'] = $lst;
			$list['size'] = db("Schedule")->where('uid',$id)->where([['plan_time','=',strtotime(date("Y-m-d"))]])->count();
			$list['status'] = 1;
		}	
		return json($list);
	}
	/**
	 * schedule
	 * 当天日程列表-》首页
	 */
	public function schedule()
	{
		$list = [];
		if(request()->isAjax()){
			$lst = db("Schedule")->where('uid',$this->uid)->where([['plan_time','=',strtotime(date("Y-m-d"))]])->select();
			foreach($lst as $key => $val){
				$lst[$key]['plan_time'] = date("Y/m/d",$lst[$key]['plan_time']);
			}
			$list['list'] = $lst;
			$list['size'] = count($lst);
			$list['status'] = 1;
		}	
		return json($list);
	}
	/**
	 * look_schedule
	 * 查看日程
	 */
	public function look_schedule()
	{
		$code = ['status'=>0];
		if(request()->isAjax()){
			$id = intval(input("id"));
			if(db("Schedule")->where(['id'=>$id,'uid'=>$this->uid])->value("id")){
				if(db("Schedule")->where(['id'=>$id,'uid'=>$this->uid])->setField("is_look",1)) $code = ['status'=>1];;
			}
		}
		return json($code);
	}
	/**
	 * 添加快递单
	 * add_express
	 */
	public function add_express()
	{
		$magazine = [];
		$code = ['status' => 0];
		if(request()->isAjax()){
			$info = input();
			$info['uid'] = $this->uid;
			if(db("Express")->where(['is_pass'=>0,'cid'=>$info['cid'],'uid'=>$this->uid])->value('id')) return json(['status'=>2,'msg'=>'你的上一次杂志单还没有寄出去呢！']);
			$info['input_time'] = time();
			$list = $info['list'];
			if($list){
				foreach($list as $key => $val){
					foreach($val as $k => $v){
						$magazine[] = [
							'type' 	 => $key,
							'cid' 	 => $info['cid'],
							'year'   => $v['year'],
							'num' 	 => $v['num'],
							'amount' => $v['amount'],
						];
					}
				}
			}
			if(model("Express")->allowField(true)->isUpdate(false)->save($info) && model("Magazine")->allowField(true)->saveAll($magazine)){
				$data = [
					'uid' 	=> $this->uid,
					'cid'	=> $info['cid'],
					'type'	=> 1,
					'form'	=> 'express',
					'keyword'=>'提交了新的快递单'
				];
				$data1 = [
					'uid' => 0,
					'content' => '有新的杂志订单需要邮寄杂志，请查看、分配。',
				];
				$this->make_operate($data);//记录
				$this->make_remind($data1);//记录
				$code = ['status' => 1,'msg' => '添加成功'];
			}
		}
		return json($code);
	}
	/**
	 * get_express
	 * 获取快递单
	 */
	public function get_express()
	{
		$data = [];
		if(request()->isAjax()){
			$id = input("id");
			$data  = model("Express")->where(['uid'=>$this->uid,'cid'=>$id])->find();
			$data['magazine'] = model('Express')->magazine($id);
		}
		return json($data);
	}
	/**
	 * 杂志派发列表
	 * express_list
	 */
	public function express_list()
	{
		$district = cache("district");
		if(request()->isAjax()){
			$map = [];$list = [];
			// if($this->rank == 3 && session("crm_type1") == 2) $map['e.kid'] = $this->uid;
			$page = input('page') ? intval(input('page')) : 1;
			$company = trim(input('company'));
			if(input('type')) $map['e.is_pass'] = 1;else $map['e.is_pass'] = 0;
			if(input("province")) $map['c.province'] = intval(input("province"));
			if(input("city")) $map['c.city'] = intval(input("city"));
			if(input("area")) $map['c.area'] = intval(input("area"));
			$info = db("Express")->alias("e")->join("Customs c","e.cid=c.id")->where($map)->where([['c.company','like','%'.$company.'%']])
					->field("c.id,c.company,c.type,c.province,c.city,c.area,c.address,e.id as eid,e.uid,e.express,e.memo,e.mode,e.num,e.is_pass,e.passid")
					->order('e.id desc')->page($page,20)->select();
			foreach($info as $key => $val){
				$info[$key]['type'] = $this->kehu_cate[$val['type']];
				$info[$key]['name'] = model("Order")->Magazine($val['id']);
				$info[$key]['express'] = $this->express[$val['express']];
				$info[$key]['xiadan'] = $this->user[$val['uid']];
				$info[$key]['lianxi'] = model("Order")->lianxi($val['id']);
				$info[$key]['dizhi'] = $district[$val['province']] . $district[$val['city']] . $district[$val['area']] . $val['address'];
			}
			$province = db("Express")->alias("e")->join("Customs c","e.cid=c.id")->column("c.province");
			
			$list['list'] = $info;
			$list['diqu'] = $this->get_city1(array_unique($province));
			$list['size'] = db("Express")->alias("e")->join("Customs c","e.cid=c.id")->where($map)->count();
			$list['status'] = 1;
		}
		return json($list);
	}
	/**
	 * magazine_pai
	 * 杂志派发
	 */
	public function magazine_pai()
	{
		$code = ['status' => 0];
		if(request()->isAjax()){
			$eid = intval(input('eid'));
			$num = trim(input('num'));
			if(!$num) return json(['status' => 2,'msg' => '请填写快递单号']);
			$res = db("Express")->where(['id'=>$eid,'is_pass'=>0])->field("id,uid,cid")->find();
			if($res){
				if(db("Express")->where(['id'=>$eid])->update(['num'=>$num,'is_pass'=>1,'passid'=>$this->uid,'pai_time'=>time()])) {
					$data = [
						'uid' 	=> $this->uid,
						'uid2' 	=> $res['uid'],
						'cid'	=> $res['cid'],
						'type'	=> 3,
						'form'	=> 'express',
						'keyword'=>'派发了杂志'
					];
					$data1 = [
						'uid' => $res['uid'],
						'content'=> $this->user[$this->uid].'给你跟进的客户'.$this->company[$res['cid']].'派发了杂志。',
					];
					$this->make_operate($data);//记录
					$this->make_remind($data1);
				$code = ['status' => 1];
			}
			}else $code = ['status' => 2,'msg' => '没找到该单子'];
		}
		return json($code);
	}
	/**
	 * 添加下单
	 * add_order
	 */
	public function add_order()
	{
		$code = ['status' => 0];
		if(request()->isAjax()){
			$info = input();
			$info["uid"] = $this->uid;
			$info['input_time'] = time();
			$info['end_time'] = strtotime($info['end_time']);
			if(db("Order")->where(['is_shen'=>0,'cid'=>$info['cid'],'uid'=>$this->uid])->value('id')) return json(['status'=>2,'msg'=>'你的上一次下单还没有进行审核呢！']);
			if($info['cr_file']){
				foreach($info["cr_file"] as $val){
					$newPic = saveBase64Img($val);
					if($newPic) $samePic[] = $newPic;
					if(sizeof($samePic) == 10) break;
				}
				$info["cr_file"] = implode(",", $samePic);
			}
			if($info['zl_file']){
				foreach($info["zl_file"] as $val){
					$newPic1 = saveBase64Img($val);
					if($newPic1) $samePic1[] = $newPic1;
					if(sizeof($samePic1) == 10) break;
				}
				$info["zl_file"] = implode(",", $samePic1);
			}
				
			if(model("Order")->allowField(true)->isUpdate(false)->save($info)){
				$daozhang['money'] = $info['mention'];
				$daozhang['did'] = model("Order")->id;
				$daozhang['cid'] = $info['cid'];
				$daozhang['uid'] = $this->uid;
				$daozhang['input_time'] = time();
				db("Arrive")->insert($daozhang);
				$data = [
					'uid' 	=> $this->uid,
					'cid'	=> $info['cid'],
					'type'	=> 1,
					'form'	=> 'order',
					'keyword'=>'提交新订单'
				];
				$data1 = [
					'uid' 	=> 0,
					'content'	=> $this->user[$this->uid].'提交了新的下单表,请您尽快前往订单列表查看进行审核。',
				];
				$this->make_operate($data);//记录
				$this->make_remind($data1);
				$code = ['status' => 1,'msg' => '添加成功'];
			}
		}
		return json($code);
	}
	/**
	 * get_order
	 * 获取订单
	 */
	public function get_order()
	{
		$data = [];
		if(request()->isAjax()){
			$id = input("id");
			$data  = model("Order")->where('id',$id)->find();
			$data['daokuan'] = model("Order")->arrive($data['id']);
			$data['end_time'] = date("Y/m/d",$data['end_time']);
		}
		return json($data);
	}
	/**
	 * 下单列表
	 * order_list
	 */
	public function order_list()
	{
		$list = [];$map = [];
		if(request()->isAjax()){
			$shen = intval(input("type"));
			if($this->rank == 3 && session("crm_type1") == 2) $map['o.kid'] = $this->uid;
			if(input('lei')) $map['a.type'] = intval(input('lei'));
			$page = input('page') ? intval(input('page')) : 1;
			if(!$shen) $map['o.is_shen'] = 0;elseif($shen == 1) $map['o.is_shen'] = 1;elseif($shen == 2) $map['o.is_shen'] = 2;
			$info = model("Order")->alias("o")->join('Customs a','o.cid=a.id')->where($map)->order("o.input_time desc")
				->field("o.id,o.uid,o.is_shen,o.input_time,a.id as cid,a.type,a.company,a.province,a.city,a.area,a.address")->page($page,20)->select();
			
			foreach($info as $key => $val){
				$info[$key]['type'] = $this->kehu_cate[$val['type']];
				$info[$key]['input_time'] = date("Y/m/d H:i",$val['input_time']);
				$info[$key]['xiadan'] = $this->user[$val['uid']];
				
				$info[$key]['lianxi'] = model("Order")->lianxi($val['cid']);
				$info[$key]['zuihou'] = model("Order")->zuihou($this->uid,$val['cid']);
			}
			$province =  model("Order")->alias("o")->join('Customs a','o.cid=a.id')->column("a.province");
			
			$list['list'] = $info;
			$list['diqu'] = $this->get_city1(array_unique($province));
			$list['leiX'] = $this->kehu_cate;
			$list['kefu'] = db("User")->where([['rank','>',1],['type1','=',2],['status','=',1]])->field("id,name")->select();
			$list['size'] = model("Order")->alias("o")->join('Customs a','o.cid=a.id')->where($map)->count();
			$list['status'] = 1;
		}
		return json($list);
	}
	
	/**
	 * order_shen
	 * 订单审核
	 */
	public function order_shen()
	{
		$code = ['status' => 0];
		if(request()->isAjax()){
			$ids = input("id");
			// $id = $ids[0];
			$advice = input("advice") ? input("advice") : '';
			$state = intval(input("type"));
			$orderinfo = db("Order")->where([['id','in',$ids],['is_shen','=',0]])->order('input_time desc')->select();
			if($state && $orderinfo){
				foreach($orderinfo as $val){
					db("Order")->where('id',$val['id'])->update(['is_shen'=>$state,'advice'=>$advice]);
					if($state == 1) db("Customs")->where('id',$val['cid'])->update(['status2'=>1]);
					$data = [
						'uid' 	=> $this->uid,
						'uid2' 	=> $val['uid'],
						'cid'	=> $val['cid'],
						'type'	=> 3,
						'form'	=> 'order',
						'keyword'=>'审核了订单'
					];
					$data1 = [
						'uid' 	=> $val['uid'],
						'content'	=> '你的下单表已通过审核，请开始进行跟踪',
					];
					$this->make_operate($data);//记录
					$this->make_remind($data1);
				}
				$code = ['status' => 1];
			}
		}
		return json($code);
	}
		/**
	 * order_fen
	 * 订单分配
	 */
	public function order_fen()
	{
		$code = ['status' => 0];
		if(request()->isAjax()){
			$id = intval(input("id"));
			$kid = intval(input("kid"));
			$info = db("User")->where(['rank'=>3,'type1'=>2,'status'=>1,'id'=>$kid])->value("id");
			$info1 = db("Order")->where(['is_shen'=>1,'id'=>$id])->field("id,cid,uid")->find();
			if($info && $info1){
				if(db("Order")->where(['is_shen'=>1,'id'=>$id])->setField('kid',$kid)){
					$data = [
						'uid' 	=> $this->uid,
						'uid2' 	=> $kid,
						'cid'	=> $info1['cid'],
						'type'	=> 3,
						'form'	=> 'Order',
						'keyword'=>'分配订单给'
					];
					$data1 = [
						'uid' 	=> $kid,
						'content'	=> session("crm_name").'分配给你新的客户订单，请你尽快前往订单列表查看跟进',
					];
					$this->make_operate($data);//记录
					$this->make_remind($data1);
					$code = ['status' => 1];
				}
			}
		}
		return json($code);
	}
	/**
	 * 添加跟进记录
	 * add_access
	 */
	public  function add_access()
	{
		$code = ['status' => 0];
		if(request()->isAjax()){
			$info = input();
			if($this->rank > 1) $info['is_zz'] = session("crm_type1");
			$info['input_time'] = time();
			$info['uid'] = $this->uid;
			if($info['file']){
				foreach($info["file"] as $val){
					$newPic = saveBase64Img($val);
					if($newPic) $samePic[] = $newPic;
					if(sizeof($samePic) == 10) break;
				}
				$info["file"] = implode(",", $samePic);
			}
			if(model("Access")->allowField(true)->isUpdate(false)->save($info)){
				$data = [
					'uid' 	=> $this->uid,
					'cid'	=> $info['cid'],
					'type'	=> 1,
					'form'	=> 'access',
					'keyword'=>'新增了'.$this->company[$info['cid']].'的跟进记录'
				];
				$data1 = [
					'uid' => 0,
					'content' => $this->user[$this->uid].'更新了"'.$this->company[$info['cid']].'"客户的跟进记录。',
				];
				$this->make_operate($data);//记录
				$this->make_remind($data1);
				$code = ['status' => 1,'msg' => '添加成功'];
			}
		}	
		return json($code);
	}
	/**
	 * my_access
	 * 我的杂志跟进()
	 */
	public function my_access()
	{
		$list = [];
		if(request()->isAjax()){
			$page = input('page') ? intval(input('page')) : 1;
			$lst = db("Express")->where(['uid'=>$this->uid,'is_pass'=>1])->order('pai_time desc')->page($page,20)->select();
			foreach($lst as $key => $val){
				$lst[$key]['express'] = $this->express[$val['express']];
				$lst[$key]['pai_time'] = date("Y/m/d",$val['pai_time']);
			}
			$list['list'] = $lst;
			$list['status'] = 1;
		}
		return json($list);
	}
	/**
	 * customer_access
	 * 客户跟进记录
	 */
	public function customer_access()
	{
		$list = [];
		if(request()->isAjax()){
			$cid = intval(input('id'));
			$data = db("Customs")->where('id',$cid)->field("id,company,input_time")->find();
			$data['input_time'] = date("Y/m/d H:i",$data['input_time']);
			$zuihou = model("Customs")->zuihoukehu($cid);
			$data['zuihou'] = $zuihou ? date('Y/m/d H:i',$zuihou) : 0;
			$page = input('page') ? intval(input('page')) : 1;
			$lst = db("Access")->where('cid',$cid)->order('input_time desc')->page($page,20)->select();
			foreach($lst as $key => $val){
				$lst[$key]['rank'] = db("User")->where('id',$val['uid'])->value("rank");
				$lst[$key]['uid'] = $this->user[$val['uid']];
				$lst[$key]['cid'] = $this->company[$val['cid']];
				$lst[$key]['input_time'] = date('Y/m/d H:i',$val['input_time']);
				$lst[$key]['type'] = $this->kehu_yixiang[$val['type']];
			}
			$list['data'] = $data;
			$list['list'] = $lst;
			$list['yixiang'] = $this->kehu_yixiang;
			$list['status'] = 1;
		}
		return json($list);
	}
	
	/**
	 * my_remind
	 * 我的提醒列表
	 */
	public function my_remind()
	{
		$list = [];
		if(request()->isAjax()){
			$page = input('page') ? intval(input('page')) : 1;
			$lst = db("Remind")->where([['uid','=',$this->uid]])->order("time desc")->page($page,20)->select();
			foreach($lst as $key => $val){
				$lst[$key]['time'] = date("Y/m/d H:i",$val['time']);
			}
			$list['list'] = $lst;
			$list['status'] = 1;
		}
		return json($list);
	}
	/**
	 * 改变提醒信息查看状态
	 * change_state
	 */
	public function change_state()
	{
		$code = ['status'=>0];
		if(request()->isAjax()){
			$id = intval(input("id"));
			if(db("Remind")->where('id',$id)->setField('clook',1)) $code = ['status'=>1];
		}
		return json($code);
	}
	/**
	 * 客户分配
	 */
	public function customer_distribution()
	{
		$code = ['status' => 0];
		if(request()->isAjax()){
			$cid = intval(input("cid"));//kehu
			$uid2 = intval(input("id"));
			if($uid == $this->uid) return json(['status' => 2,'msg' => '这是你的客户，不需要再分配给自己了']);
			if(db("Customs")->where(['id'=>$cid,'status2'=>1])->value('id')) return json(['status' => 2,'msg' => '已合作的客户不能再分配了！']);
			$res = db("Customs")->where(['id'=>$cid])->setField('uid',$uid2);
			if($res){
				$data = [
					'uid' 	=> $this->uid,
					'uid2'	=> $uid2,
					'cid'	=> $cid,
					'type'	=> 3,
					'form'	=> 'customs',
					'keyword'=>'分配客户'.$this->company[$cid].'给'.$this->user[$this->uid],
				];
				$data1 = [
					'uid' 	=> $uid2,
					'content'	=> $this->user[$this->uid].'给你分配客户'.$this->company[$cid].',请开始进行跟踪。'
				];
				$this->make_operate($data);//记录
				$this->make_remind($data1);
				$code = ['status' => 1,'msg' => '分配成功'];
			}
		}
		return json($code);
	}
	/**
	 * 客户保护
	 */
	public function customer_protect()
	{
		$code = ['status' => 0];
		if(request()->isAjax()){
			$cid = intval(input('cid'));
			if($cid){
				$res = db("Customs")->where('id',$cid)->field("id,protect_time,isprivate")->find();
				if(!$res) return json(['status' => 2,'msg' => '找不到ID']);
				$info['protect_time'] = $info['protect_time'] +24*60*60*30;
				$info['isprivate'] = 1;
				$info['uid'] = $this->uid;
				if(model("Customs")->isUpdate(true)->save($info,['id' => $cid])){
					$data = [
						'uid' 	=> $this->uid,
						// 'uid2'	=> 2,
						'cid'	=> $cid,
						'type'	=> 3,
						'form'	=> 'customs',
						'keyword'=>'对客户‘'.$this->company[$cid].'’进行了保护'
					];
					$this->make_operate($data);//记录
					$code = ['status' => 1,'msg' => '保护成功'];
				};
			}
		}
		return json($code);
	}
	/**
	 * 客户释放
	 */
	public function customer_release()
	{
		$code = ['status' => 0];
		if(request()->isAjax()){
			$cid = intval(input('cid'));
			if($cid){
				if(model("Customs")->isUpdate(true)->save(['protect_time' => time() + 60*60],['id' => $cid])){
					$data = [
						'uid' 	=> $this->uid,
						// 'uid2'	=> 2,
						'cid'	=> $cid,
						'type'	=> 3,
						'form'	=> 'customs',
						'keyword'=>'释放了客户'.$this->user[$cid],
					];
					$this->make_operate($data);//记录
					$code = ['status' => 1,'msg' => '释放成功'];
				};
			}
		}
		return json($code);
	}
	/**
	 * 更改头像
	 * make_face
	 */
	public function make_face()
	{
		$code = ['status' => 0];
		if(request()->isAjax()){
			$face = saveBase64Img(input('face'),1);
			if($face){
				$user_face = db("User")->where('id',$this->uid)->value('face');
				if(!delPic($user_face)) {
					$info = [
						'uid' => $this->uid,
						'file'=> $user_face,
						'input_time'=> time(),
					];
					db("Log")->insert($info);
					$code = ['status' => 2,'msg' => '原图片删除失败'];
				}else{
					db("User")->where('id',$this->uid)->setField ('face',$face);
					$code = ['status' => 1,'msg' => '上传成功'];
				}
			}else $code = ['status' => 0,'msg' => '无效图片'];
		}
		return json($code);
	}
	/**
	 * operate_list
	 * 操作日志列表
	 */
	public function operate_list()
	{
		$type = [1 =>'添加',2 => '删除',3 => '修改',4 => '查询'];
		$list = [];
		if(request()->isAjax()){
			$id = $this->uid;
			$page = input('page') ? intval(input('page')) : 1;
			$lst = db("Operate")->where(['uid'=>$id])->order("time desc")->page($page,20)->select();
			foreach($lst as $key => $val){
				$lst[$key]['type'] = $type[$val['type']];
				$lst[$key]['uid'] = $this->user[$val['uid']];
				$lst[$key]['uid2'] = $this->user[$val['uid2']];
				$lst[$key]['cid'] = $this->company[$val['cid']];
				$lst[$key]['time'] = date("Y/m/d H:i",$val['time']);
			}
			$list['list'] = $lst;
			$list['status'] = 1;
		}
		return json($list);
	}
	/**
	 * customer_schedule
	 * 公海客户、日程提醒
	 */
	public function customer_schedule()
	{
		$data = [];
		if(request()->isAjax()){
			$data['customer'] = $this->new_customer();
			$data['schedule'] = $this->new_schedule();
		}
		return json($data);
	}
	/**
	 * ___________________________________________________________________________________________________________________________________________________
	 * 
	 * +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 * ___________________________________________________________________________________________________________________________________________________
	 */
	/**
	 * make_operate
	 * 操作日志
	 */
	protected function make_operate($data)
	{
		$data['time'] = time();
		model("Operate")->allowField(true)->isUpdate(false)->data($data)->save();
	}
	/**
	 * make_remind
	 * 提醒记录
	 */
	protected function make_remind($data)
	{
		$data['time'] = time();
		model("Remind")->allowField(true)->isUpdate(false)->data($data)->save();
	}
	/**
	 * 检测是否有客户到期释放，有就释放，不再是保护状态
	 */
	protected function chek_shifang()
	{
		$ids = db("Customs")->where([['status','=',1],['isprivate','=',1],['protect_time','<',time()]])->column("id");
		if($ids){
			foreach($ids as $val){
				db("Customs")->where('id',$val)->update(["isprivate"=>0,"new"=>1,'protect_time'=>time()]);
			}
		}
	}
	/**
	 * 检测与客户合作是否到期，到期回到自己的保护客户
	 */
	protected function chek_hezuo()
	{
		
		$Customs2 = db("Order")->alias('o')->join("Customs c","o.cid=c.id")->field('o.uid,o.cid,o.end_time')->where([['c.isprivate','=',1],['o.end_time','<=',time()+3*24*60*60],['c.status2','=',1],['c.is_ji','=',0]])->order("o.end_time desc")->select();
		
		if($Customs2){//合作即将到期的客户
			foreach($Customs2 as $val){
				db("Customs")->where('id',$val['cid'])->update(['is_ji'=>1]);
				$data1 = [
					'uid' => $val['uid'],
					'content' => $this->company[$val['cid']].'合作客户即将到期。',
				];
				$this->make_remind($data1);//记录
			}
		}
		$Customs = db("Order")->alias('o')->join("Customs c","o.cid=c.id")->field('o.uid,o.cid,o.end_time')->where([['c.isprivate','=',1],['o.end_time','<',time()],['c.status2','=',1],['c.is_ji','=',1]])->order("o.end_time desc")->select();
		if($Customs){//合作到期的客户
			foreach($Customs as $val){
				db("Customs")->where('id',$val['cid'])->update(['protect_time'=>time()+30*24*60*60,'status2'=>0]);
				$data1 = [
					'uid' => $val['uid'],
					'content' => $this->company[$val['cid']].'合作客户已过期。',
				];
				$this->make_remind($data1);//记录
			}
		}
	}
	
	/**
	 * 检测与用户离职时间是否到期,到期名下的跟进客户自动给上级
	 */
	protected function chek_user_leave()
	{
		$user = db("User")->where([['leave_time', ['<', time()], ['<>', 0], 'and'],['status','=',2]])->order("leave_time desc")->field('id,pid,leave_time')->select();//到期离职的用户
		if($user){
			foreach($user as $val){
				db("Customs")->where('uid',$val['id'])->update(['uid'=>$val['pid']]);
				db("User")->where('id',$val['id'])->update(['status'=>3]);
			}
		}
	}
	/**
	 * public_customer
	 * 公海客户数量
	 */
	protected function new_customer()
	{
		$newCustomer = db("Customs")->where([["isprivate",'=',0],['protect_time','<',time()],['status2','=',0]])->count();
		return $newCustomer;
	}
	/**
	 * new_schedule
	 * 今天日程提醒数量
	 */
	protected function new_schedule()
	{
		$newSchedule = db("Schedule")->where(['uid'=>$this->uid,'is_look'=>0])->where([['plan_time','=',strtotime(date("Y-m-d"))]])->count();
		return $newSchedule;
	}
	/**
	 * new_remind
	 * 今天消息提醒数量（销售）
	 */
	protected function new_remind()
	{
		$newRemind = db("Remind")->where([['uid','=',$this->uid,'clook'=>0]])->count();
		return $newRemind;
	}
	/**
	 * new_remindB
	 * 今天消息提醒数量（客服B）
	 */
	protected function new_remindB()
	{
		$order = db("Order")->where(['is_shen'=>0,'clook'=>0])->count();
		$genjin = db("Access")->where([['is_zz','in',[0,1]],['clook','=',0]])->count();
		$newRemind = $order + $genjin;
		return $newRemind;
	}
	/**
	 * new_remindC
	 * 今天消息提醒数量（客服C）
	 */
	protected function new_remindC()
	{
		$access = db("Access")->where([['is_zz','=',2],['clook','=',0],['uid','=',$this->uid]])->count();
		$zazhi = db("Express")->where([['uid','=',$this->uid],['clook','=',0],['is_pass','=',1]])->count();
		$newRemind = $access + $zazhi;
		return $newRemind;
	}
	/**
	 * ___________________________________________________________________________________________________________________________________________________
	 * 
	 * +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 * ___________________________________________________________________________________________________________________________________________________
	 */
	/**
	 * 短信验证，时间为60秒：sms_code_start_time
	 */
	public function chekMsm()
	{
		$sms_code = input("sms_code");//验证码
		$reInfo = array();//返回信息
		//截取登录验证部分start
		if(ISLOCALHOST){
			$reInfo['status'] = 1;
			//设置登录时间
			// session("admin_nextLogin", time()+60*30);
			return json($reInfo);
		}
		//截取登录验证部分end
		if(!ISLOCALHOST){
			if(time() - session("sms_code_start_time") <= 60*5){
				if($this->check_sms_code($sms_code)){
					$reInfo['status'] = 1;
					//设置登录时间
					// session("admin_nextLogin", time()+60*30);
				}else{
					$reInfo['info'] = "验证码错误";
				}
			}else{
				$reInfo['info'] = "验证码过期，请重新发送";
			}
			return json($reInfo);
		}
		
	}

	/**
	 * ajax重新发送短信
	 * 是否过了60秒
	 */
	public function ajaxSms()
	{
		$new = intval(input("new"));
		$reInfo = array();
		if($new==1){
			$this->do_send_sms(session("admin_phone"));
			$reInfo['status'] = 1;
		}else{
			$reInfo['info'] = "非法操作";
		}
		return json($reInfo);
	}
	

	/**
	 * 发送 验证码
	 * @return obj  success 和  message
	 */
	private function do_send_sms($phone){
	    $sms = new Sms();
	    return $sms->send_sms($phone);
	}

	// 验证 短信 验证码
	private function check_sms_code($sms_code)
	{
	    $this->set_sms_code();// 过期 就 删除 短信 验证码
	    if(md5($sms_code) == session("sms_code"))
	    {
            session("sms_code",NULL);
            session("sms_code_start_time",NULL);
	        return true;
	    }
	    return false;
	}

	// 计算 短信 验证 是否 过期
	private function set_sms_code()
	{
	    // 十分钟 之内 验证码 有效
	    if(time() - session("sms_code_start_time") > 600)
	    {
	        session("sms_code",NULL);
	        session("sms_code_start_time",NULL);
	    }
	}
	/**
	 * 退出登录
	 */
	public function loginOut(){
		$code = ['status' => 0];
		if(request()->isAjax()){
			$res = db("User")->where('id',$this->uid)->field("id,name,sex,phone,rank,pid,input_time,type1,type2,status")->find();
			foreach ($res as $key => $val){
				session('crm_'.$key, null);
			}
			session("imageTimes", null);
			$code = ['status' => 1];
		}
		return json($code);
	}
	public function ajaxDistrict()
    {
		$list= [];
		if(request()->isAjax()){
			$map['pid'] = intval(input("pid"));
			$map['type'] = intval(input("type"));
			$data = db("District")->where($map)->field("id,name")->select();
			$list['list'] = $data;
			$list['status'] = 1;
		}
        return json($list);
	}
	//get_city_name
	public function get_city_name()
    {
		if(request()->isAjax()){
			$map['id'] = intval(input("id"));
			$name = db("District")->where($map)->value("name");
		}
        return json($name);
	}
}
