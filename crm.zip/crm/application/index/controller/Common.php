<?php
namespace app\index\Controller;
use think\Controller;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\PhpWord;

    /**
    * 公共调用方法
    */
    class Common extends Controller
    {
        
        //生成EXCEL表格
        public function make_excel()
        {dump("lkjkkjlksd");exit;
            $list = db('Good')->where(['status'=>1])->field("id,title,model,input_time,status")->limit(20)->select();

            $objPHPExcel = new \PHPExcel();

            $objPHPExcel->getProperties()->setCreator("ctos")
                ->setLastModifiedBy("ctos")
                ->setTitle("Office 2007 XLSX Test Document")
                ->setSubject("Office 2007 XLSX Test Document")
                ->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")
                ->setKeywords("office 2007 openxml php")
                ->setCategory("Test result file");
            //单元宽度
            $objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(8);
            $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(30);
            $objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(13);
            $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(14);
            $objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(8);

            //设置行高度
            $objPHPExcel->getActiveSheet()->getRowDimension('1')->setRowHeight(30);

            $objPHPExcel->getActiveSheet()->getRowDimension('2')->setRowHeight(30);
            $objPHPExcel->getActiveSheet()->getRowDimension('23')->setRowHeight(80);

            //字体大小
            $objPHPExcel->getActiveSheet()->getDefaultStyle()->getFont()->setSize(14);
            // $objPHPExcel->getActiveSheet()->getStyle('A1:E2')->getFont()->setBold(true);

            // $objPHPExcel->getActiveSheet()->getStyle('A2:E2')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
            $objPHPExcel->getActiveSheet()->getStyle('A2:E2')->getBorders()->getAllBorders()->setBorderStyle(\PHPExcel_Style_Border::BORDER_THIN);
            //单元边框
            $styleThinBlackBorderOutline = array(
                'borders' => array(
                    'allborders' => array( //设置全部边框
                        'style' => \PHPExcel_Style_Border::BORDER_THIN //粗的是thick
                    ),
        
                ),
            );
            //设置水平居中
            // $objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
            $objPHPExcel->getActiveSheet()->getStyle('A')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            $objPHPExcel->getActiveSheet()->getStyle('B')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            $objPHPExcel->getActiveSheet()->getStyle('C')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            $objPHPExcel->getActiveSheet()->getStyle('D')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            $objPHPExcel->getActiveSheet()->getStyle('E')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
            $objPHPExcel->getActiveSheet()->getStyle('A1:E23')->applyFromArray($styleThinBlackBorderOutline);

            //合并cell
            $objPHPExcel->getActiveSheet()->mergeCells('A1:E1');
            $objPHPExcel->getActiveSheet()->mergeCells('A23:E23');

            // set table header content
            $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue('A1', '产品数据汇总  时间:'.date('Y-m-d H:i:s'))
                ->setCellValue('A2', '产品ID')
                ->setCellValue('B2', '产品名称')
                ->setCellValue('C2', '产品型号')
                ->setCellValue('D2', '添加时间')
                ->setCellValue('E2', '状态')
                ->setCellValue('A23', '这是表尾');

    
            // Miscellaneous glyphs, UTF-8
            for($i=0;$i<count($list)-1;$i++){
                $objPHPExcel->getActiveSheet(0)->setCellValue('A'.($i+3), $list[$i]['id']);
                $objPHPExcel->getActiveSheet(0)->setCellValue('B'.($i+3), $list[$i]['title']);
                $objPHPExcel->getActiveSheet(0)->setCellValue('C'.($i+3), $list[$i]['model']);
                $objPHPExcel->getActiveSheet(0)->setCellValue('D'.($i+3), date("Y-m-d",$list[$i]['input_time']));
                if($list[$i]['status'] == 1) $ss = "正常";else $ss = "不正常";
                $objPHPExcel->getActiveSheet(0)->setCellValue('E'.($i+3), $ss);
                //$objPHPExcel->getActiveSheet()->getStyle('A'.($i+3).':J'.($i+3))->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER);
                //$objPHPExcel->getActiveSheet()->getStyle('A'.($i+3).':J'.($i+3))->getBorders()->getAllBorders()->setBorderStyle(\PHPExcel_Style_Border::BORDER_THIN);
                //$objPHPExcel->getActiveSheet()->getRowDimension($i+3)->setRowHeight(16);
            }


            //  sheet命名
            $objPHPExcel->getActiveSheet()->setTitle('产品列表');


            // Set active sheet index to the first sheet, so Excel opens this as the first sheet
            $objPHPExcel->setActiveSheetIndex(0);


            // excel头参数
            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment;filename="产品列表('.date('Ymd').').xls"');  //日期为文件名后缀
            header('Cache-Control: max-age=0');

            $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');  //excel5为xls格式，excel2007为xlsx格式

            $objWriter->save('php://output');
        }
        //生成WORD文档
        public function make_word()
        {
            $PHPWord = new PhpWord();
            // New portrait section
            $section = $PHPWord->createSection();
            $arr['project_name'] = '云桥';
            $arr['buy_start_time'] = '20180515';
            $arr['buy_end_time'] = '20190825';
            $arr['start_s'] = '20190825';
            $arr['end_s'] = '20190825';
            $arr['total'] = 25;
            $arr['tfee'] = 2500;
            // Add text elements
            $str = "        ".$arr['project_name']."项目，与腾讯房产于".$arr['buy_start_time']."至".$arr['buy_end_time']."开展腾讯电商团购合作，".$arr['start_s']."至".$arr['end_s']."内，共计售出房屋". $arr['total']."套，成交明细见附件，收取服务费合计".$arr['tfee']."元，特此证明。";
            $str5 = "        本确认函中的房源均已通过网签为确认标准，经双方授权代表签字后生效作为收款确认依据。且一旦签字盖章，乙方将不再承担该房源后续的电商团购费的退款责任。";
            $str1 = "甲    方：                                                           乙    方：";
            $str2 = "授权代表签字：  　                                              授权代表签字：";
            $str3 = "盖章：                                                                  盖章：";
            
            $str4 = "签约时间：20        年        月        日                                    签约时间：20         年        月        日";
            $title = '<h1>腾讯电商合作成交签约确认函</h1>';
            $section->addText($title,'rStyle','pStyle');
            $section->addTextBreak(2);
            $section->addText($str,'cOntent');
            $section->addTextBreak(2);
            $section->addText($str5,'cOntent');
            $section->addTextBreak(2);
            // $section->addText(iconv('utf-8','GB2312//IGNORE',$str1),'cOntent');
            // $section->addText(iconv('utf-8','GB2312//IGNORE',$str2),'cOntent');
            // $section->addText(iconv('utf-8','GB2312//IGNORE',$str3),'cOntent');
            // $section->addText(iconv('utf-8','GB2312//IGNORE',$str4),'cOntent');
            $section->addText($str1,'cOntent');
            $section->addText($str2,'cOntent');
            $section->addText($str3,'cOntent');
            $section->addText($str4,'cOntent');
            $section->addTextBreak(2);
    //        $section->addText('I am inline styled.', array('name'=>'Verdana', 'color'=>'006699'));
            $section->addTextBreak(2);
            $PHPWord->addFontStyle('cOntent', array('bold'=>false, 'size'=>12));
            $PHPWord->addFontStyle('rStyle', array('bold'=>true, 'italic'=>false, 'size'=>16,'align'=>'center'));
            $PHPWord->addParagraphStyle('pStyle', array('align'=>'center', 'spaceAfter'=>100));
    //        $section->addText('I am styled by two style definitions.', 'rStyle', 'pStyle');
    //        $section->addText('I have only a paragraph style definition.', null, 'pStyle');
    //         Save File
            $objWriter = IOFactory::createWriter($PHPWord, 'Word2007');
            header("Content-Type: application/doc");
            header("Content-Disposition: attachment; filename=".date("YmdHis").".doc");
            $objWriter->save('php://output');
        }
    }
