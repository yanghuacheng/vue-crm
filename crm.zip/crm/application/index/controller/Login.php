<?php
namespace app\index\controller;
use think\Controller; 
use sms\Sms;
class Login extends Controller{
	public function index()
	{
		$root = SCRIPT_DIR;
		return $this->fetch('./admin/index.html',['rootpath'=>$root]);
	}
	/**
	 * 登录验证
	 */
	public function logincheck(){
		$errorInfo = ['status'=>0,'msg'=>'操作失败！'];
		if(request()->isAjax()){
			$model = db("user");
			$info['name|phone'] = trim(input("name"));
			$info['password'] = md5(sha1(trim(input("password"))));
			$res = $model->where($info)->field("id,name,sex,phone,rank,pid,input_time,type1,type2,status")->find();
			// $code = input("code");
			// $checkCode = $this->check_verify($code); 
			if($res){
				if($res['status'] == 3){
					$errorInfo = ['status'=>2,'msg'=>'登录失败，您已离职，不能再登陆！'];
					return json($errorInfo);
				}elseif(in_array($res['status'],[1,2])){
					
					$errorInfo = ['status'=>1,'msg'=>'登陆成功！','userinfo'=>$res];
					
					foreach ($res as $key => $val)
					{
						session('crm_'.$key,$val ? $val : null);
					}

					return json($errorInfo);
				}
			}else{
				$errorInfo = ['status'=>2,'msg'=>'登录失败，账号或密码错误！'];
			}
			
		}
		return json($errorInfo);
	}

	
}