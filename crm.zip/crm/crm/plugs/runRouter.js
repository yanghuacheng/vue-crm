'use strict';
var modelPath = rootPaths + '/model/';
var viewPath =  rootPaths + '/html/';
define(['jQ', 'expand', 'cookie'], function() {
	$.newPage = function(model, name, local) {
		if(!model) {model = {};};
		var copy = $.copyObj(model);
		// this.delimiters = ['{[', ']}'],
		this.data = function() {
			var Obj = $.assignObj({
				config: {
					url: "", //请求地址/ylx/ylx/Ylxcms/data_select
					metheds: ["get"], //请求方式，是否异步
					clear: true, // 是否重置模型
					pageSize: 30, // 请求数量
					model:'ad_city'
				},
				dataArr:[],
				dataList:[],
				query: {page: 0},
				page:{index:1,show:5,pages:10},
				list: [],
				reloads:false,

				scrool:false,
				newpages:1,
				objs: {},
				initdata: copy,
				orlast:false,
				diqu:[],
				shenfen:{},
				size:0,
				zazhiobj:[],
				kuaidi:{},
				kefu:[],
				zuida:null,
				yixiang:{},
				other:{},
				cityquery:{
					provincen:'',
					province:0,
					cityn:'',
					city:0,
					arean:'',
					area:0
				},
				typelst:{}
			}, model, true);
			Obj.Root = rootData;
			return Obj;
		};
		if(name) {
			if(!local) {
				var Strs = $.getStatic($.resetUrl([viewPath, name + '.html']));
				this.template = '<div>' + Strs.html + '</div>';
			} else {
				this.template = '<div>' + name + '</div>';
			};
		} else {
			this.template = '<div>未指定模板文件</div>';
		};
		
		$.newPage.prototype.created = function() {this.init();};
		$.newPage.prototype.mounted = function() {};
		this.methods = {
			init: function(tys) {
				this.orlast = false;
				this.reloads = false;
				// this.scrool = false;
				var cofg = this.config;
				var URLs = cofg.url;
				URLs = URLs.split('?')[0];
				this.linkto = this.$route.path;
				var data = $.copyObj(this.$route.query);
				var newp = $.copyObj(this.query);
				this.query = {};
				$.assignObj(this.query,this.$route.query);
				if(tys){
					if(this.newpages){
						data.page = this.newpages;
					};
				}else{
					this.newpages = 1;
					delete data['page'];
				};
				if(this.$route.query.company){
					this.sear.company = this.$route.query.company;
				};
				if(this.$route.query.lai){
					this.sear.lai = this.$route.query.lai;
				};
				if(this.$route.query.isprivate){
					this.sear.isprivate = this.$route.query.isprivate;
				};
				if(this.$route.query.lei){
					this.sear.lei = this.$route.query.lei;
				};
				if(this.$route.query.province){
					this.cityquery.province=this.$route.query.province;
					this.getcitys(this.$route.query.province,'provincen');
				};
				if(this.$route.query.city){
					this.cityquery.city=this.$route.query.city;
					this.getcitys(this.$route.query.city,'cityn');
				};
				if(this.$route.query.area){
					this.cityquery.area=this.$route.query.area;
					this.getcitys(this.$route.query.area,'arean');
				};	
				if(this.$route.query.time1){
					this.time = this.$route.query.time1;
				};
				if(this.$route.query.time2){
					this.time1 = this.$route.query.time2;
				};			
				// data.pageSize = cofg.pageSize;
				// if(cofg.model){
				// 	data.model = cofg.model;
				// };
				// var arrmap = this.rejson(data);
				// data.map = arrmap;
				// data.order = 'id asc';
				if(!URLs) {return;};
				if(cofg.metheds[0] == 'get' && !cofg.metheds[1]) {$.getT(URLs, data, this.setdate);
				} else if(cofg.metheds[0] == 'get' && cofg.metheds[1]) {this.setdate($.getF(URLs, data));
				} else if(cofg.metheds[0] == 'post' && !cofg.metheds[1]) {$.postT(URLs, data, this.setdate);
				} else if(cofg.metheds[0] == 'post' && cofg.metheds[1]) {this.setdate($.postF(URLs, data));}
			},
			getcitys:function(id,str){
				var url = wwwroot + '/index/index/get_city_name';
				var _this = this;
				$.getT(url,{id:id},function(res){
					_this['cityquery'][str] = res;
				});
			},
			//周期监听
			event: function(way, parm) {
				// console.log(way, parm)
			},
			setdate: function(data) {
				var _this = this;
				var zuida = this.zuida ? this.zuida : 20;
				if(data.status){
					// this.page.pages = data.page;
					if(data.list.length>=zuida){
						_this.scrool = false;
						_this.orlast = false;
					}else{
						_this.orlast = true;
					};
					
					setTimeout(function(){
						_this.reloads = true;
						$.assignArr(_this.list, data.list);
					},500);
					
					if(data.diqu){
						$.assignArr(this.diqu, data.diqu, true);
					};
					if(data.shenfen){
						this.shenfen = data.shenfen;
					};
					if(data.size || data.size == 0){
						this.size = data.size;
					};
					if(data.leiX){
						this.typelst = data.leiX;
					};
					if(data.kefu){
						this.kefu = data.kefu;
					};
					if(data.zazhi){
						this.zazhiobj = [];
						for(var i in data.zazhi){
							var obj = {};
							obj.id = i;
							obj.type = 0;
							obj.name = data.zazhi[i];
							obj.cont = [{year:'',num:'',amount:''}]
							this.zazhiobj.push(obj);
						}
					};
					if(data.kuaidi){
						this.kuaidi = data.kuaidi;
					};
					if(data.yixiang){
						this.yixiang = data.yixiang;
					};
					if(data.data){
						this.other = data.data;
					};
					this.Root.root = data.root;
					this.event('created', '默认数据接收完毕');
				}else{
					if(!data.msg){
						this.showmsg('数据请求失败',true);
					}else{
						this.showmsg(data.msg,true);
					};
					return false;
				}
			},
			//重定义query参数，用于路由跳转
			reQuery: function(key, val ,slt) {
				// if(key !== 'page'){
				// 	this.query['page'] = 0;
				// };
				if(typeof(key) == 'string'){
					this.query[key] = val;
				}else{
					for(var i in key){
						this.query[i] = key[i];
					}
				}
				var query = $.copyObj(this.$route.query);
				var querys = $.copyObj(this.query);
				for(var o in querys){
					if(!querys[o]){delete querys[o];if(query[o]){delete query[o]}};
				};
				this.$router.push({
					path: this.linkto,
					query: $.assignObj(query, querys,true)
				});
			},
			//是否拼接根目录
			resrc:function(obj){
				if(!obj){
					return ''
				}
				if(obj.substr(0,4) == 'data'){
					return obj;
				}else{
					if(this.Root.root){
						var objs = this.Root.root + obj;
					};
					return objs
				}
			},
			
			//打开新对象
			newObj: function(str) {},
			//重置对象
			resetObj: function() {$.assignObj(this, this.initdata);},
			//重置查询条件
			resetQuery: function() {this.query = this.initObj.query;},
			//清空数组
			clearList: function(arr) {$.clearArr(arr);},
			//初始化对象
			initObj: function(Obj) {$.initObj(Obj);}
		};
		$.newPage.prototype.computed = {};
		$.newPage.prototype.watch = {
			$route: function() {
				$('#totop').hide();
				// this.list = [];
				// this.init();
			}
		};
		$.newPage.prototype.update = function() {};
		$.newPage.prototype.beforeCreate = function() {

		};
		$.newPage.prototype.beforeUpdate = function() {};
		$.newPage.prototype.destroyed = function() {};
		$.newPage.prototype.beforeDestroy = function() {
			var clear = this.config.clear;
			if(clear) {
				this.resetObj(); //页面离开重置参数
			}
		};
	};
	// 设置路由模型
	$.addR = function(objs, routes) {
		if(!objs.url) {
			return
		};
		var obj = {};
		obj.path = objs.url;
		if(objs.pathname) {
			var nowdata = $.getStatic('/' + $.resetUrl([viewPath, objs.pathname + '.html'])).html;
			if(nowdata.indexOf("data=Vues") !== -1) {
				var scriptStr = nowdata.substr(nowdata.indexOf('<script'), nowdata.length);
				scriptStr = scriptStr.replace(scriptStr.substr(0, scriptStr.indexOf('>') + 1), '(function (){').replace('</script>', '})()');
				var comModel = eval(scriptStr);
				if(!comModel){comModel = new $.newPage();};
				comModel.template = '<div>' + nowdata.substr(0, nowdata.indexOf('<script')) + '</div>';
				obj.component = comModel;
			} else {
				obj.component = function component(resolve) {
					require('/' + [$.resetUrl([modelPath, objs.pathname])], resolve);
				};
			}
			if(!obj.component){
				obj.component = new $.newPage({}, nowdata, true);
			}
		};
		
		if(objs.redirect) {
			obj.redirect = objs.redirect;
		};
		if(objs.name) {
			obj.name = objs.name;
		};
		for(var c in routes){
			if(routes[c].path == obj.path){
				routes.splice(c,1);
			}
		}
		routes.push(obj);
	};
});