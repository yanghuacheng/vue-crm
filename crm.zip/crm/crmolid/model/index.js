define(function() {
    var obj = new $.newPage({
        page:{
            show:5,
            index:1,
            pages:10
        },
        config:{
        	url:'/admin/jiekou.php',
        	metheds:['get',true]
        }
    },'index');
    obj.created= function(){
    	alert('model')
        this.init();
    };
    obj.methods.addp=function(){
    	this.reQuery('page', this.page.index);
    };
    obj.mounted = function(){
    };
    return obj;
});
