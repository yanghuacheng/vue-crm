define(function() {
    var obj = new $.newPage({},'about');
    obj.created= function(){
        alert('about')
    }
    return obj;
});