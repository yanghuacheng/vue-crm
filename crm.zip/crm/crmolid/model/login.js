define(function() {
    var obj = new $.newPage({
        page:{
            show:5,
            index:3,
            pages:10
        },
        asd:123
    },'login');
    obj.created= function(){
        this.init();
        
    };
    obj.mounted = function(){
        // console.log(this.page)
    };
    return obj;
});
