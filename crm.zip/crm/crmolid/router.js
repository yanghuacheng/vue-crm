"use strict"
define(['vueRouter','runRouter'],function(R){
	var routes = [];
	///add 参数一{url:路由地址，redirect：从定向地址，pathname：静态文件名，model：是否加载模型页（none不加载），name：路由别名，login：是否需要登录验证}  参数二：路由对象数组
	for(var i in pages){
		if(i<=1){
			continue;
		};
		var str = pages[i].replace('.html','');
		$.addR({url:'/' + str,pathname:str},routes);
	};
	$.addR({url:'/',redirect:'/index'},routes);
	var router = new R({
		saveScrollPosition: true,	// 路由模式	// mode: 'history',	// hashbang: true,	// history: true,	 	// transitionOnLoad: true,
		routes:routes
	});
	//路由跳转前钩子函数
	router.beforeEach(function (to, from, next) {
		// 登录验证
		if(to.path !== '/login'){
			//	需在登陆页设置loginStatic cookie
				if($.cookie('loginStatic') == "true"){
					$.cookie('loginStatic',"true",1);
					next();
				}else{
					next('/login');
				};
		}else{
			next();
		};
		if(to.matched.length === 0){///未匹配到路由跳转404页面
			location.href = './400/404.html';
		}else{
			next()
		};
		
    });
	return router;
});