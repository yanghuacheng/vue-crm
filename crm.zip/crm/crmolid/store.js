'use strict';
define(['vue', 'vueStore', 'jQ'], function(V, S) {
	V.use(S);
	var store = new S.Store({
		state: {
			poslist:[],
			num:0,
			num1:0
		},
		//等同于方法store.commit(方法名)调用
		mutations: {
			increment:function(state) {
				state.count++
			},
			getnew:function(){
				var url = wwwroot + '/index/index/customer_schedule';
				var _this = this;
				$.ajax({
					type: 'GET',
					url: url,
					dataType:'json',
					data:{},
					beforeSend: function (xhr) {},
					success: function success(data, status) {
							_this.state.num = data.customer;
							_this.state.num1 = data.schedule;
					},
					error: function (err) {
						
					},
					complete: function complete(XHR, TS) {
						XHR = null;
					}
				});
			}
		},
		//等同于计算属性store.getters调用
		getters:{
			gogo:function(state){
				return 123;
			},
			getarr:function(state){
				var sta = state;
//				console.log(sta)
				// return function(id){
				// 	return state.arr
				// }	
			}
		},
		
	});
	return store;
});