
define(['rootModel', 'jQ'], function () {
	var componet = {};
	//name:注册组件名称，pathname：静态文件名，model:是否加载模型（none不加载）
	for(var i in coms){
		if(i<=1){
			continue;
		};
		var str = coms[i].replace('.html','');
		$.addC({ name: str, pathname: str }, componet);
	};

	//初始化全局模型
	var plugs = {
		install: function (Vue) {
			Vue.mixin({
				// delimiters: ['{[', ']}'],
				data: function () { return {wTop:window.innerHeight} },
				created: function () { },
				methods: {
				},
				// mounted:function(){

				// },
				components: componet,
				methods: {
					linkTo:function(src){
						window.open('#' + src);
					},
					// 退出登录清除cookie
					delsesson: function (name, url) {
						$.cookie(name, null);
						if (url) {
							this.$router.push(url);
						}
					},
					setsesson: function (name, val, time) {
						$.cookie(name, val, { expires: time });
					},
					getinfo:function(){
						return JSON.parse($.cookie('userInfo'));
					},
					retime:function(str,rep){
						if(!str){
							return '';
						};
						var fege = '/';
						if(rep){
							fege = rep;
						};
						var date = new Date(str);//如果date为13位不需要乘1000
						var Y = date.getFullYear() + fege;
						var M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + fege;
						var D = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()) + ' ';
						var h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':';
						var m = (date.getMinutes() <10 ? '0' + date.getMinutes() : date.getMinutes()) ;
						// var s = (date.getSeconds() <10 ? '0' + date.getSeconds() : date.getSeconds());
						return Y+M+D+h+m;
					},
					reclook:function(o,tys){
						this.showtext = o.content;
						this.msg = true;
						if(o.clook){
							return;
						};
						if(o.is_look){
							return;
						};
						var urlss = wwwroot + '/index/index/change_state',_this = this;
						if(tys){
							urlss = wwwroot + '/index/index/look_schedule';
						}
						
						if(o.clook){
							return;
						}
						$.getT(urlss,{id:o.id},function(res){
							if(res.status == 1){
								_this.list=[];
								_this.init();
								if(_this.getdata){
									_this.getdata(wwwroot + '/index/index/my_remind','tixing');
									_this.getdata(wwwroot + '/index/index/schedule','richeng');
								};
								if(_this.getx){
									_this.getx();
								};
							}else{
								_this.showmsg('操作失败');
							}
						});
						
					},
					gobotton:function(num,num1){
						if(!num){
							num = 0;
						};
						if(!num1){
							num1 = 20;
						};
						var _this = this;
						$(window).scroll(function(){
							var scrollTop = $(this).scrollTop();
							if(scrollTop>150){
								$('#totop').show();
							}else{
								$('#totop').hide();
							};
							if(_this.scrool){return;};
						　　var scrollHeight = $(document).height();
						　　var windowHeight = $(this).height();
						　　if(scrollTop + windowHeight >= scrollHeight - num){
								if(_this.list.length>=num1){
									_this.scrool = true;
									_this.newpages = Number(_this.newpages) + 1;
									_this.init(true);
								}
						　　};
						});
					},
					timecha:function(time_end,time_start){
							// var time_start = new Date().getTime(); //设定当前时间
							// var time_end =  new Date("2019/5/26 12:00:00").getTime(); //设定目标时间2019年5月26号12点
							// 计算时间差
							if(!time_start){
								time_start = new Date().getTime();
							}
							// console.log(new Date().getTime())
							var time_distance = time_end - time_start;
							// 天
							var int_day = Math.floor(time_distance/86400000)
							time_distance -= int_day * 86400000;
							// 时
							var int_hour = Math.floor(time_distance/3600000)
							time_distance -= int_hour * 3600000;
							// 分
							var int_minute = Math.floor(time_distance/60000)
							time_distance -= int_minute * 60000;
							// 秒
							var int_second = Math.floor(time_distance/1000)
							// 时分秒为单数时、前面加零
							// if(int_day < 10){
							// 	int_day = "0" + int_day;
							// }
							// if(int_hour < 10){
							// 	int_hour = "0" + int_hour;
							// }
							// if(int_minute < 10){
							// 	int_minute = "0" + int_minute;
							// }
							// if(int_second < 10){
							// 	int_second = "0" + int_second;
							// }
							return [int_day,int_hour,int_minute,int_second];
					},
					///弹窗
					//标题，内容，dom对象名称
					newAlert: function (title, content, dom) {
						var name = '',
							Str = '';
						if (dom) {
							name = dom;
						} else {
							name = 'dom';
						};
						if (!content && !title) {
							content = '这是提示内容';
							title = '这是提示标题'
						};
						if (title) {
							Str += '<header>' + title + '</header>';
						};
						if (content) {
							Str += '<div class="main"> ' + content + ' </div>';
						};
						Str += '<button>确定</button>';
						$('#app').append('<div class="' + name + '">' + Str + '</div><div class="alert-Show"></div>');
						$('.' + name).css('position', 'fixed').css('left', '50%').css('top', '40%').css('transform', 'translate(-50%,-60%)').css('-webkit-transform', 'translate(-50%,-60%)').css('z-index', '10')
							.css('border', '1px solid #ccc').css('border-radius', '.08rem').css('width', '6rem').css('background', '#fff');
						$('.' + name + '>*').css('padding', '.15rem .2rem').css('text-align', 'center');
						$('.' + name + ' header').css('border-bottom', '1px solid #ccc');
						$('.' + name + ' button').css('border', 'none').css('border-top', '1px solid #ccc').css('width', '100%').css('outline', 'none')
							.css('color', '#1AAD19').css('background', 'none').css('font-size', '.18rem').click(function () {
								$('.' + name).remove();
								$('.alert-Show').remove();
							});
						$('.alert-Show').css('position', 'fixed').width('100%').height('100%').css('top', 0).css('left', 0).css('z-index', '9')
							.css('background', 'rgba(0,0,0,.6)');
					},
					//消息推送
					//title:提示内容    type:默认成功 true失败(主题)    
					showmsg: function (title, type) {
						$('.showmsg').remove();
						if (!title) {
							title = '操作成功';
						};
						$('#app').append('<div class="showmsg">' + title + '</div>');
						$('.showmsg').height('40').css('position', 'fixed').css('left', '50%').css('top', '-50px').css('transform', 'translateX(-50%)').css('-webkit-transform', 'translateX(-50%)');
						$('.showmsg').css('z-index',100000).css('background', '#f0f9eb').css('color', '#2fa1fa').css('border', '1px solid #e1f3d8').css('line-height', '40px').css('padding', '0 50px').css('border-radius', '.05rem');
						if (type) {
							$('.showmsg').css('background', '#fef0f0').css('border', '1px solid #fde2e2').css('color', 'red');
						};
						$('.showmsg').animate({ 'top': '100px' }, 500);
						setTimeout(function () {
							$('.showmsg').animate({ 'top': '-50px', 'opacity': 0 }, 300);
						}, 2500);
					}
				}
			});
		}
	}
	return plugs;
});

