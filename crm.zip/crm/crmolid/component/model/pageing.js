define(['rootModel'], function(a) {
    'use strict';
    var obj = $.newcompone('pageing');
	obj.computed =  {
			arr: function () {
				if(this.$route.query.page){
					this.obj.index = Number(this.$route.query.page);
				};
				var arr = [], num = 0, index = this.obj.index, pages = this.obj.pages, show = this.obj.show, left = parseInt(show / 2);
				if (index < 1) { this.obj.index = 1; };
				if (index > pages) { this.obj.index = pages };
				if (show > pages) { show = pages; };
				if (index <= left) { num = 1; }
				else if (index + left > pages) { num = pages - show + 1; }
				else { num = index - left; };
				console.log(index,left,pages)
				for (var i = 0; i < show; i++) { arr.push(num + i); };
				return arr;
			}
		}
    return obj;
});	