"use strict";
require.config({
	baseUrl: rootPaths+'/',
	preserveLicenseComments: false, //是否保留注释
	waitSeconds: 0,
	paths: {
		vue: rootPaths+'/plugs/vue.min',
		vueRouter: rootPaths+'/plugs/vue-router.min',
		vueStore: rootPaths+'/plugs/vuex.min',
		jQ: rootPaths+'/plugs/jquery-2.1.0',
		router: rootPaths+'/router',
		store: rootPaths+'/store',
		text: rootPaths+'/plugs/text.min',
		runRouter: rootPaths+'/plugs/runRouter',
		expand: rootPaths+'/plugs/expand',
		compone:rootPaths+'/component/component',
		rootModel:rootPaths+'/plugs/rootModel',
		cookie:rootPaths+'/plugs/jq.cookie'
	},
	shim: {
		vue: {exports: 'Vue'},vueRouter: {deps: ['vue']},vueStore: {deps: ['vue']},compone: {deps: ['vue']},runRouter:{deps: ['jQ']},router: {deps: ['vueRouter']},store: {deps: ['vueStore']},expand: {deps: ['jQ']},cookie: {deps: ['jQ']}
	}
});
var rootData = {//全局变量，路由之间通讯
	path:rootPaths
};

require(['vue', 'vueStore', 'store', 'vueRouter', 'router' , 'compone','jQ'], function (vue, vueStore, store, vueRouter, router,compone) {
	// console.log($.cookie('loginStatic'))

//	vue.config.debug = true; // 开启调试模式
//	vue.config.devtools = true; // 开启开发者工具
	vue.use(vueRouter);
	vue.use(vueStore);
	vue.use(compone,{ someOption: true });
	var vm = new vue({
		el: "#app",
		// delimiters: ['{[', ']}'],
		store: store,
		router: router,
		data: function () {
		 	return {
		 		Root:rootData,
		 		pages:{
		 			index:1,
		 			show:15,
		 			pages:100
				 },
				 zhankai:true,
				 list:[],
				 list1:[],
				 list2:[],
				 list3:[],
				 other:{}
		 	}
		},
		created: function () {//创建完成时粗发函数
			this.$store.commit('getnew');
			
		},
		methods:{//方法

			// 退出登录
			delLogin:function(){
				var _this = this;
				var url = wwwroot + '/index/index/loginOut';
				$.getT(url,{},function(res){
					if(res.status == 1){
						_this.delsesson('userInfo');
						_this.delsesson('loginStatic');
						_this.$router.push('/login');
					}else{	
						_this.showmsg('退出登录失败',true); 
					}
				})
			},
			getname:function(){
				// console.log($.cookie('userInfo'))
				return JSON.parse($.cookie('userInfo')).name;
			}
		},
		mounted:function(){//加载完成时
			setTimeout(function(){
				$('.con-right').height(window.innerHeight - 50);
			},200);
			$('#totop').click(function(){
				$('body,html').animate({scrollTop: 0 }, 100);  
			});
		},
		computed:{//计算属性
		},
		watch:{//监听属性
		}
	})
});
