<!DOCTYPE html>
<?php 
	$root = rtrim(dirname($_SERVER['SCRIPT_NAME']),'\/\\');//根目录
	$pages = scandir(__DIR__ . '/html');//分页列表
	// $models = scandir(__DIR__ . '/model');
	$coms = scandir(__DIR__ . '/component/html'); //组件列表
	// $comsmodels = scandir(__DIR__ . '/component/model');//组件模型列表
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
		<meta name="viewport" content="width=device-width,target-densitydpi=high-dpi,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
		<link rel="stylesheet" href="<?php echo $root; ?>/public/css/home.css">
		<link rel="stylesheet" href="<?php echo $root; ?>/public/css/component.css">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<script>
			var rootPaths = '<?php echo $root; ?>';
			var pages = <?php echo json_encode($pages); ?>;
			var coms = <?php echo json_encode($coms); ?>;
			var wwwroot = rootPaths.replace(rootPaths.split('/')[rootPaths.split('/').length - 1],'');
			wwwroot = wwwroot.replace('/','');
		</script>
		<script src="<?php echo $root; ?>/public/js/GetTime/WdatePicker.js"></script>
		<script src="<?php echo $root; ?>/plugs/require.min.js" data-main = "<?php echo $root; ?>/main.js" type="text/javascript" charset="utf-8"></script>

	</head>
	<body>
		<div id="app">
			<!-- 公用头部 -->
			<div id="header" v-if="$route.path != '/login'">
				<img :src="Root.path + '/public/images/log-1.jpg'" alt="">
				<p :class="{'show':getinfo().rank == 3 && getinfo().type2 == 2}">———————客服C类版本</p>
				<p :class="{'show':getinfo().rank == 3 && getinfo().type2 == 1}">———————客服C类杂志版本</p>
				<p :class="{'show':getinfo().rank == 3 && getinfo().type2 == 0}">———————销售C类版本</p>
				<p :class="{'show':getinfo().rank == 2 && getinfo().type1 == 2}">———————客服B类版本</p>
				<p :class="{'show':getinfo().rank == 2 && getinfo().type1 == 1}">———————销售B类版本</p>
				<ul class="setdata">
					<!-- active控制提醒角标显示 -->
					<li class="active" style="margin-right:35px;" v-if="getinfo().type1 != 2">
						<router-link to="/com">
							<img :src="Root.path + '/public/images/4-2.png'" alt="" style="margin-top:12px;">
							<small style="left:15px;" v-if="$store.state.num">{{$store.state.num}}</small>
							<p style="margin-left:15px;">公共客户</p>
						</router-link>
					</li>
					<!-- <li class="active">
						<router-link to="">
							<img :src="Root.path + '/public/images/sousuo.png'" alt="" style="margin-top:12px;">
							<p>查询</p>
						</router-link>
					</li> -->
					<li class="active" style="margin-right:45px;">
						<router-link to="/guanli">
							<img :src="Root.path + '/public/images/ric.jpg'" alt="">
							<small v-if="$store.state.num1">{{$store.state.num1}}</small>
							<p>日程提醒</p>
						</router-link>
					</li>
					<li>
						<router-link :to="'/userdetail?id=' + getinfo().id">
							<img :src="Root.path + '/public/images/userhead.jpg'" alt="">
							<p>{{getname()}}</p>
						</router-link>
					</li>
					<li><button v-on:click="$router.push('/rizhi')">操作日志</button></li>
					<li><button v-on:click="delLogin()">退出</button></li>
				</ul>
			</div>
			<!-- 左导航 -->
			<div class="nav-left" v-if="$route.path != '/login'" :class="{'actived':!zhankai}">
				<ul v-if="getinfo().rank == 0">
					<li class="show" :class="{'active':$route.path == '/user'}">
						<router-link to="/user">人员管理</router-link>
					</li>
				</ul>
				<ul v-if="getinfo().rank > 1">
					<li :class="{'active':$route.path == '/index' || $route.path == '/indexc','show':getinfo().type2 == 0}">
						<router-link to="/indexc" v-if="getinfo().type1 == 2">首页</router-link>
						<router-link to="/index" v-else>首页</router-link>
					</li>
					<li :class="{'active':$route.path == '/list','show':getinfo().type1 == 1}" >
						<router-link to="/list">我的客户</router-link>
					</li>
					<li :class="{'active':$route.path == '/add','show':getinfo().type2 == 0}">
						<router-link to="/add">添加客户</router-link>
					</li>
					<li :class="{'active':$route.path == '/com','show':getinfo().type2 == 0}">
						<router-link to="/com">公共资源</router-link>
					</li>
					
					<li :class="{'active':$route.path == '/paisong','show':getinfo().rank > 1 && getinfo().type1 == 2 && getinfo().type2 != 2}">
						<router-link to="/paisong">杂志派发</router-link>
					</li>
					<li :class="{'active':$route.path == '/orderlst' || $route.path == '/orderlstc','show':getinfo().type1 == 2 }" >
						<router-link to="/orderlst" v-if="getinfo().type2 == 0">订单列表</router-link>
						<router-link to="/orderlstc" v-else>订单列表</router-link>
					</li>
					<li class="show" :class="{'active':$route.path == '/guanli'}">
						<router-link to="/guanli">日程管理</router-link>
					</li>
					<li :class="{'active':$route.path == '/user','show':getinfo().rank != 3}">
						<router-link to="/user">人员管理</router-link>
					</li>
					<li class="show" :class="{'active':$route.path == '/password'}">
						<router-link to="/password">修改密码</router-link>
					</li>
				</ul>
				<ul v-if="getinfo().rank == 1">
					<li class="show" :class="{'active':$route.path == '/index' || $route.path == '/indexc'}">
						<router-link to="/index">首页</router-link>
					</li>
					<li class="show" :class="{'active':$route.path == '/list'}" >
						<router-link to="/list">我的客户</router-link>
					</li>
					<li class="show" :class="{'active':$route.path == '/add'}">
						<router-link to="/add">添加客户</router-link>
					</li>
					<li class="show" :class="{'active':$route.path == '/com','show':getinfo().type2 == 0}">
						<router-link to="/com">公共资源</router-link>
					</li>
					<li class="show" :class="{'active':$route.path == '/guanli'}">
						<router-link to="/guanli">日程管理</router-link>
					</li>
					<li class="show" :class="{'active':$route.path == '/paisong'}">
						<router-link to="/paisong">杂志派发</router-link>
					</li>
					<li class="show" :class="{'active':$route.path == '/orderlst' || $route.path == '/orderlstc'}" >
						<router-link to="/orderlst">订单列表</router-link>
					</li>
					<li class="show" :class="{'active':$route.path == '/user'}">
						<router-link to="/user">人员管理</router-link>
					</li>
					<li class="show" :class="{'active':$route.path == '/password'}">
						<router-link to="/password">修改密码</router-link>
					</li>
				</ul>
				<img v-if="zhankai" v-on:click="zhankai = !zhankai" :src="Root.path + '/public/images/goleft.png'" />
				<img v-else v-on:click="zhankai = !zhankai" :src="Root.path + '/public/images/goright.png'"/>
			</div>
			<!-- <button>top</button> -->
			<img id="totop" :src="Root.path + '/public/images/gotop.png'" alt="">
			<div class="con-right" :class="{'active':zhankai,'logined':$route.path == '/login'}">
				<keep-alive>
				<router-view></router-view>
				</keep-alive>
			</div>
		</div>
	</body>
</html>
