define(['jQ'], function () {
	'use strict';
	//替换对象,or是否返回值
	$.assignObj = function (nowObj, oldobj, or) {
		for (var k in oldobj) {
			var obj = oldobj[k];
			if (typeof (obj) == "object" && !$.isEmptyObject(obj)) {
				if (typeof (nowObj[k]) == "object") {
					$.assignObj(nowObj[k], obj);
				} else {
					nowObj[k] = obj;
				}
			} else if (typeof (obj) == "function" && $.replace(obj.toString(), ' ', '') == "function(){}") {} else {
				nowObj[k] = obj;
			}
		};
		if (or) {
			return nowObj;
		}
	};



	
	///转换键值  arr数组对象，key键名，val键值，name取得键名
	$.toName = function (arr, key, val, name) {
		var Str = '';
		if (!name) {
			name = 'name';
		};
		for (var i in arr) {
			var o = arr[i];
			if (o[key] === val) {
				Str = o[name];
				break;
			} else {
				Str = null;
			}
		};
		return Str;
	};



	///过滤数组对象 arr：列表 key：键名 val：键值
	$.filter = function (arr, key, val) {
		var lt = [];
		if (arr) {
			for (var i in arr) {
				var o = arr[i];
				if (o[key] === val) {
					lt.push(o);
				}
			}
		}
		return lt;
	}
	//检测滚动条是否到底
	$.gobottom = function(func,num){
		if(!num){
			num = 0;
		}
		$(window).scroll(function(){
			var type = false;
		　　 var scrollTop = $(this).scrollTop();
		　　var scrollHeight = $(document).height();
		　　var windowHeight = $(this).height();
		　　if(scrollTop + windowHeight >= scrollHeight - num){
		　　　　type = true;
		　　};
			if(type){
				if(func){
					func();
				};
				// alert(123)
			};
		});
	};
	//拷贝对象
	$.copyObj = function (obj) {
		var newobj = {};
		for (var attr in obj) {
			if (typeof obj[attr] == 'object') {
				newobj[attr] = $.copyObj(obj[attr]);
			} else {
				newobj[attr] = obj[attr];
			}
		};
		return newobj;
	};
	// 替换数组nowArr:新数组 oldArr:旧数组 or是否替换 默认是添加
	$.assignArr = function (nowArr, oldArr, or) {
		if(typeof(nowArr) != 'array'){
			
		};
		if (or) {
			nowArr.splice(0,nowArr.length);
		};
		for(var i in oldArr){
			nowArr.push(oldArr[i]);
		}
	};

	///数组去重
	$.repeat = function (arr, or) {
		var obj = {};
		for (var i in arr) {
			if (!obj[arr[i]]) {
				obj[arr[i]] = 1;
			} else {
				arr.splice(i, 1);
			}
		};
		if (or) {
			return arr;
		}
	};

	// 初始化对象
	$.initObj = function (obj) {
		for (var key in obj) {
			var type = typeof (obj[key]);
			switch (type) {
				case "string":
					obj[key] = "";
					break;
				case "number":
					obj[key] = 0;
					break;
				case "boolean":
					obj[key] = false;
					break;
				case "function":
					obj[key] = function () {};
					break;
				default:
					obj[key] = null;
					break;
			}
		};
	};
	/// get请求获取数据
	/// url：提交网址（文本型）
	/// identity：是否附加身份（用于oauth身份验证）
	/// 返回json对象
	$.getF = function (url, param,identity) {
		var json = {};
		$.ajax({
			type: 'GET',
			url: url,
			dataType:'json',
			data: param,
			async: false,
			beforeSend: function (xhr) {

			},
			success: function success(data, status) {
				if (status == 'success' && data) {
					json = data;
				}
			},
			complete: function complete(XHR, TS) {
				XHR = null;
			}
		});
		return json;
	};

	/// get请求获取数据——异步
	/// url：提交网址（文本型）
	/// fun：回调方法
	/// identity：是否附加身份（用于oauth身份验证）
	$.getT = function (url, param,fun, identity) {
		if (fun) {
			$.ajax({
				type: 'GET',
				url: url,
				dataType:'json',
				data:param,
				beforeSend: function (xhr) {},
				success: function success(data, status) {
					if (fun) {
						fun(data);
					}
				},
				error: function (err) {
					if (fun) {
						fun(err);
					}
				},
				complete: function complete(XHR, TS) {
					XHR = null;
				}
			});
		}
	};

	/// post请求获取数据
	/// url：提交网址（文本型）
	/// param：传递参数（Json对象）
	/// identity：是否附加身份（用于oauth身份验证）
	/// 返回json对象
	$.postF = function (url, param, identity) {
		var json = {};
		$.ajax({
			type: 'POST',
			url: url,
			data: JSON.stringify(param),
			contentType: "application/json;charset=utf-8;",
			dataType: "json",
			async: false,
			beforeSend: function (xhr) {},
			success: function success(data, status) {
				if (status = "success" && data) {
					json = data;
				}
			},
			error: function (err) {
				json = err;
			},
			complete: function complete(XHR, TS) {
				XHR = null;
			}
		});
		return json;
	};
	/// post请求获取数据——异步
	/// url：提交网址（文本型）
	/// param：传递参数（Json对象）
	/// identity：是否附加身份（用于oauth身份验证）
	/// fun：回调方法
	$.postT = function (url, param, fun) {
		$.ajax({
			type: 'POST',
			url: url,
			data: param,
			// contentType: "application/json;charset=utf-8;",
			dataType: "json",
			beforeSend: function (xhr) {

			},
			success: function success(data) {
				if (fun) {
					fun(data);
				}
			},
			error: function (err) {
				console.log(err)
				if (fun) {
					fun(err);
				}
			}
		});
	};

	/// http请求
	/// url：提交网址（文本型）
	/// param：传递参数（文本型）
	/// type：请求方式（文本型），GET 或 POST
	/// dataType：传递数据的类型（文本型） json、text
	/// 返回对象型
	$.http = function (url, param, type, dataType) {
		if (!type) {
			type == 'GET';
		}
		var ret = null;
		$.ajax({
			type: type,
			url: url,
			data: param,
			dataType: dataType,
			async: false,
			success: function success(data, status) {
				ret = data;
			},
			error: function (err) {
				ret = err;
			},
			complete: function complete(XHR, TS) {
				XHR = null;
			}
		});
		return ret;
	};

	/// 获取http请求的Referrer
	$.getReferrer = function () {
		var referrer = document.referrer;
		if (!referrer) {
			try {
				if (window.opener) {
					// ie下如果跨域则抛出权限异常
					// safari和chrome下window.opener.location没有任何属性 
					referrer = window.opener.location.href;
				}
			} catch (e) {}
		}
		return referrer;
	};

	/// 获取URL中的路由路径
	/// url：链接
	/// 返回链接
	$.getUrlPath = function (url) {
		var arr = url.split('/');
		arr.splice(arr.length - 1, 1);
		var path = "";
		for (var o in arr) {
			path += "/" + o;
		}
		return path;
	};

	/// 获取URL中的域名
	/// url：链接
	/// 返回链接
	$.getDomainName = function (url) {
		var domainName = "";
		if (url) {
			var arr = url.split('/');
			if (arr.length > 2) {
				domainName = arr[2];
			}
		}
		return domainName;
	};

	/// 获取URL的参数
	$.getUrlQuery = function (url) {
		var param = {};
		var arr = url.match(/[?].*/);
		if (arr) {
			if (arr.length > 0) {
				var query = arr[0].replace('?', '');
				var qs = query.split('&');
				for (var i = 0; i < qs.length; i++) {
					var o = qs[i];
					var ar = o.split('=');
					if (ar.length > 1) {
						var key = ar[0];
						param[key] = ar[1];
					}
				}
			}
		};
		return param;
	};
	/// 获取url中的参数
	/// name：参数名
	$.getQuery = function (name) {
		if (name){
			var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i"); // 匹配目标参数
			var result = location.search.substr(1).match(reg); // 对querystring匹配目标参数
			if (result != null) {
				return decodeURIComponent(result[2]);
			} else {
				return null;
			}
		} else {
			return $.getUrlQuery(location.href);
		}
	};

	//同步获取静态文件html/php/jsp/js
	$.getStatic = function (Url) {
		var content = {};
		$.ajax({
			type: "get",
			url: Url,
			async: false,
			success: function (res) {
				content.html = res;
				content.state = 1;
			},
			error: function (err) {
				if (err.status !== 200) {
					content.html = err.responseText;
					content.state = 0;
				} else {
					content.html = err.responseText;
					content.state = 1;
				}
			}
		});
		return content;
	};

	// 发送访问来源数据
	// 用于判断推广来源、关键词和平台
	$.sendReferrer = function (data) {
		var uuid = $.getUuid();
		var param = {
			referrer: $.getReferrer(),
			client: $.getClient(),
			data: data,
			uuid: uuid
		};
		$.postAsync('/api/BigData', param);
	};
	// 替换字符串——所有
	// txt：被替换的文本
	// oldStr：替换的字符串
	// newStr：替换为字符串
	$.replace = function (txt, oldStr, newStr) {
		while (txt.indexOf(oldStr) != -1) {
			txt = txt.replace(oldStr, newStr);
		}
		return txt;
	}
	//
	// 日期函数
	Date.prototype.getLength = function (a, b) { //a年，b月,获取月中的天数,参数为空获取当月
		if (!a) {
			a = new Date().getFullYear();
		};
		if (!b) {
			b = new Date().getMonth();
		}
		return new Date(a, b, 0).getDate();
	};
	Date.prototype.getWeek = function (a, b, c) { //获取某日期是周几，a:年，b月，c日，参数为空获取当天
		if (!a) {
			a = new Date().getFullYear();
		};
		if (!b) {
			b = new Date().getMonth();
		};
		if (!c) {
			c = new Date().getDate();
		}
		return new Date(a, b, c).getDay();
	};
	Date.prototype.Format = function (fmt) { //author: meizz 
		var o = {
			"M+": this.getMonth() + 1, //月份 
			"d+": this.getDate(), //日 
			"h+": this.getHours(), //小时 
			"m+": this.getMinutes(), //分 
			"s+": this.getSeconds(), //秒 
			"q+": Math.floor((this.getMonth() + 3) / 3), //季度 
			"S": this.getMilliseconds() //毫秒 
		};
		if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
		for (var k in o)
		if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
		return fmt;
	};
	$.retime = function(str,rep){
		var fege = '/';
		if(rep){
			fege = rep;
		};
		var date = new Date(str);//如果date为13位不需要乘1000
		var Y = date.getFullYear() + fege;
		var M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + fege;
		var D = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()) + ' ';
		var h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':';
		var m = (date.getMinutes() <10 ? '0' + date.getMinutes() : date.getMinutes()) ;
		// var s = (date.getSeconds() <10 ? '0' + date.getSeconds() : date.getSeconds());
		return Y+M+D+h+m;
	};
	//调用new Date().Format("yyyy-MM-dd");new Date().Format("yyyy-MM-dd HH:mm:ss");new Date().getWeek(2017,4,22);new Date().getLength(2018,8)
	$.getLocalTime = function (nS,ty) {    
		var newD =  new Date(parseInt(nS) * 1000).toLocaleString().substr(0,17).replace('上午','');
		newD = newD.replace('下午','');
		if(ty){
			newD = newD.split(' ')[0];
		};
		return newD}  ;
	//把数组拼接成标准url
	$.resetUrl = function (arr) {
		var Url = '';
		for (var i = 0; i < arr.length; i++) {
			if (arr[i].indexOf('./') !== -1) {
				arr[i] = $.replace(arr[i], './', '');
				arr[i] = $.replace(arr[i], '/', '');
				arr[i] = $.replace(arr[i], '/\/', '');
			};
			if (arr[i][0] == '/') {
				arr[i] = arr[i].substr(1, arr[i].length - 1)
			}
			if (arr[i][arr[i].length - 1] == '/') {
				arr[i] = arr[i].substr(0, arr[i].length - 1)
			};
			if (i !== arr.length - 1) {
				arr[i] = arr[i] + '/';
			};
			Url += arr[i];
		};
		return Url;
	};

	//格式化请求参数
	$.toUrl = function (obj) {
		var Str = '';
		for (var o in obj) {
			if (obj[o]) {
				Str += '&' + o + '=' + obj[o];
			}
		}
		var newStr = Str.substr(1, Str.length)
		return newStr;
	};

	// 清空数组
	// arr：被清空的数组（对象型数组）
	$.clearArr = function (arr) {
		if (arr && typeof (arr) == 'Array') {
			arr.splice(0, arr.length);
		} else {
			return arr;
		}
	};

});