define(['expand'], function () {
	var componetvPath = rootPaths +  '/component/html';
	var componetmPath =  rootPaths + '/component/model';
	//组件初始模块
	$.newcompone = function (templates,local) {
		var Str = '';
		if(templates){
			if(local){
				Str = templates;
			}else{
				Str = $.getStatic('/' + $.resetUrl([componetvPath, templates + '.html'])).html;
			}
		}else{
			Str = '<div>未设置模板</div>'
		};
		return {
			template: Str,
			data: function () {
				return {
					name: 123
				}
			},
			props: {
				num: {
					type: Number,
					default: 0
				},
				ints: {
					type: Number,
					default: 0
				},
				text: {
					type: String,
					default: ""
				},
				name: {
					type: String,
					default: ""
				},
				list: {
					type: Array,
					default: function _default() {
						return [];
					}
				},
				list1: {
					type: Array,
					default: function _default() {
						return [];
					}
				},
				list2: {
					type: Array,
					default: function _default() {
						return [];
					}
				},
				obj: {
					type: Object,
					default: function _default() {
						return {};
					}
				},
				objs:{
					type: Object,
					default: function _default() {
						return {};
					}
				},
				msobj:{
					type: Object,
					default: function _default() {
						return {};
					}
				},
				query:{
					type: Object,
					default: function _default() {
						return {};
					}
				},
				func: {
					type: Function,
					default: function _default(idx, obj) {
						return null;
					}
				},
				guolv: {
					type: Function,
					default: function _default(idx, obj) {
						return null;
					}
				},
				getfen: {
					type: Function,
					default: function _default(idx, obj) {
						return null;
					}
				},
				sub: {
					type: Function,
					default: function _default(idx, obj) {
						return null;
					}
				},
				showmsg: {
					type: Function,
					default: function _default(idx, obj) {
						return null;
					}
				},
				upload: {
					type: Function,
					default: function _default(idx, obj) {
						return null;
					}
				},
				val: {
					type: [String, Number, Boolean],
					default: ''
				}
			},
			created: function () {
				// alert('asdasd')
			},
			methods: {

			},
			computed: {

			},
			watch: {

			},
			update: function () {

			},
			mounted: function () {

			},
			beforeCreate: function () {

			},
			beforeUpdate: function () {

			},
			destroyed: function () {

			},
			beforeDestroy: function () {

			}

		}
	};
	// 生成组件
	var componentModel = {};
	$.addC = function (obj, com) {
		if (!obj || !com) {
			return;
		};
		var model; //实例化模型
		if (obj.name) {
			if (obj.pathname) {
				if (!obj.model) {
					var Str = $.getStatic('/' + $.resetUrl([componetvPath, obj.pathname + '.html'])).html;
					var Idx = Str.indexOf('<script'),
						Type = Str.indexOf("data=Vue"); //检测当前组件是否配置模型
					if (Idx == -1) { 
						model = $.newcompone(Str,true);
					}else {
						if (Type !== -1) {
							model = $.newcompone(Str.substr(0, Idx),true);
							var Evl = Str.substr(Idx, Str.length);
							Evl = Evl.replace(Evl.substr(0, Evl.indexOf('>') + 1), '(function (){').replace('</script>', '})()');
							var comModel = eval(Evl);
							$.assignObj(model, comModel);
						} else {
							model = $.newcompone(Str.substr(0, Idx),true);
						}
					};
					com[obj.name] = model;
				} else {
					com[obj.name] = function (resolve){
						require(['/' + $.resetUrl([componetmPath,obj.pathname])],resolve);
					};
				}
			}
		}
	};
	// return 123;
});